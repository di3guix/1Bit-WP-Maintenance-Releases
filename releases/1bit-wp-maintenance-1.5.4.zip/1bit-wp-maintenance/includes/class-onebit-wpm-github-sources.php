<?php
/**
 * Actualizaciones desde GitHub para plugins que no tienen otro canal.
 *
 * Algunos plugins se distribuyen solo como releases de GitHub (PRO Elements): WordPress no
 * sabe de dónde bajar sus versiones nuevas y quedan viejos para siempre. Para los repositorios
 * de esta lista fija, se consulta la última release y, si es más nueva, se anuncia en el
 * transient de actualizaciones como cualquier otra. Así el orquestador la instala con el mismo
 * ciclo de backup, verificación y rollback.
 *
 * Solo se aceptan paquetes publicados en la propia release del repositorio de la lista.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Github_Sources {

	const CACHE       = 'onebit_wpm_github_releases';
	const CACHE_OK    = 6 * HOUR_IN_SECONDS;
	const CACHE_ERROR = HOUR_IN_SECONDS;

	/**
	 * Carpeta del plugin => repositorio y nombre del zip en la release.
	 */
	const SOURCES = array(
		'pro-elements' => array(
			'repo'  => 'proelements/proelements',
			'asset' => 'pro-elements.zip',
		),
	);

	public static function boot() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ), 20 );
	}

	public static function inject( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		foreach ( get_plugins() as $file => $data ) {
			$folder = dirname( $file );
			if ( ! isset( self::SOURCES[ $folder ] ) ) {
				continue;
			}

			$release = self::latest( $folder );
			if ( is_wp_error( $release ) ) {
				continue;
			}

			$entry = (object) array(
				'id'          => $file,
				'slug'        => $folder,
				'plugin'      => $file,
				'new_version' => $release['version'],
				'url'         => 'https://github.com/' . self::SOURCES[ $folder ]['repo'],
				'package'     => $release['package'],
			);

			if ( version_compare( $release['version'], $data['Version'], '>' ) ) {
				$transient->response[ $file ] = $entry;
				unset( $transient->no_update[ $file ] );
			} else {
				$transient->no_update[ $file ] = $entry;
				unset( $transient->response[ $file ] );
			}
		}

		return $transient;
	}

	/**
	 * @return array|WP_Error {version, package} de la última release.
	 */
	public static function latest( $folder ) {
		$cache = get_site_transient( self::CACHE );
		$cache = is_array( $cache ) ? $cache : array();

		if ( isset( $cache[ $folder ] ) ) {
			$hit = $cache[ $folder ];
			return isset( $hit['error'] ) ? new WP_Error( 'onebit_wpm_github', $hit['error'] ) : $hit;
		}

		$release = self::fetch( self::SOURCES[ $folder ] );

		$cache[ $folder ] = is_wp_error( $release ) ? array( 'error' => $release->get_error_message() ) : $release;
		set_site_transient( self::CACHE, $cache, is_wp_error( $release ) ? self::CACHE_ERROR : self::CACHE_OK );

		return $release;
	}

	private static function fetch( array $source ) {
		$response = wp_remote_get(
			'https://api.github.com/repos/' . $source['repo'] . '/releases/latest',
			array(
				'timeout'    => 15,
				'user-agent' => 'OneBit-WPM/' . ONEBIT_WPM_VERSION . '; ' . home_url(),
				'headers'    => array( 'Accept' => 'application/vnd.github+json' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'onebit_wpm_github', 'No se pudo consultar GitHub: ' . $response->get_error_message() );
		}
		if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'onebit_wpm_github', 'GitHub respondió HTTP ' . wp_remote_retrieve_response_code( $response ) );
		}

		$data    = json_decode( wp_remote_retrieve_body( $response ), true );
		$version = isset( $data['tag_name'] ) ? ltrim( (string) $data['tag_name'], 'vV' ) : '';
		if ( ! preg_match( '/^\d+(\.\d+)+$/', $version ) || ! empty( $data['draft'] ) || ! empty( $data['prerelease'] ) ) {
			return new WP_Error( 'onebit_wpm_github', 'La última release de ' . $source['repo'] . ' no tiene una versión válida.' );
		}

		// El zip tiene que estar en la release de ese mismo repositorio, no en otro lado.
		$prefix = 'https://github.com/' . $source['repo'] . '/releases/download/';
		foreach ( isset( $data['assets'] ) ? (array) $data['assets'] : array() as $asset ) {
			$url = isset( $asset['browser_download_url'] ) ? (string) $asset['browser_download_url'] : '';
			if ( isset( $asset['name'] ) && $source['asset'] === $asset['name'] && 0 === strpos( $url, $prefix ) ) {
				return array(
					'version' => $version,
					'package' => $url,
				);
			}
		}

		return new WP_Error( 'onebit_wpm_github', 'La release ' . $version . ' de ' . $source['repo'] . ' no trae ' . $source['asset'] . '.' );
	}
}
