<?php
/**
 * Plugin Name:       1Bit WP Maintenance
 * Plugin URI:        https://1bit.com.ar
 * Description:       Actualizaciones remotas de plugins y temas con backup, verificación de salud y rollback automático. Se opera desde el orquestador central de 1Bit.
 * Version:           1.5.2
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            1Bit
 * Author URI:        https://1bit.com.ar
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       1bit-wp-maintenance
 * Update URI:        https://github.com/di3guix/1Bit-WP-Maintenance-Releases
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ONEBIT_WPM_VERSION', '1.5.2' );
define( 'ONEBIT_WPM_FILE', __FILE__ );
define( 'ONEBIT_WPM_DIR', plugin_dir_path( __FILE__ ) );
define( 'ONEBIT_WPM_REST_NAMESPACE', 'onebit-wpm/v1' );

// Clave pública Ed25519 con la que se verifican las versiones publicadas del plugin.
// La genera "python wpmaint.py keygen"; la privada queda solo en secrets.json.
define( 'ONEBIT_WPM_UPDATE_PUBKEY', 'UqFk2NIIt7Xq75t1Wx9teYObIXOZyM9d+uJNEJyT6Po=' );

require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-log.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-token.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-guard.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-backups.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-crypto.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-db-snapshots.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-health.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-updater.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-self-update.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-rest.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-diagnostics.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-malware.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-licenses.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-admin.php';
require_once ONEBIT_WPM_DIR . 'includes/class-onebit-wpm-plugin.php';

register_activation_hook( __FILE__, array( 'OneBit_WPM_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'OneBit_WPM_Plugin', 'deactivate' ) );

OneBit_WPM_Plugin::boot();
