<?php
/**
 * Endpoints REST para el orquestador.
 *
 * Autenticación doble: contraseña de aplicación (usuario con permisos de
 * actualización) + token en la cabecera X-1Bit-Token.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Rest {

	public static function register_routes() {
		$ns          = ONEBIT_WPM_REST_NAMESPACE;
		$permission  = array( __CLASS__, 'permission' );
		$paths_arg   = array(
			'type'    => 'array',
			'items'   => array( 'type' => 'string' ),
			'default' => array( '/' ),
		);

		register_rest_route(
			$ns,
			'/status',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'status' ),
				'permission_callback' => $permission,
				'args'                => array(
					'refresh' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/update',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'update' ),
				'permission_callback' => $permission,
				'args'                => array(
					'type'         => array(
						'required' => true,
						'type'     => 'string',
						'enum'     => array( 'plugin', 'theme' ),
					),
					'item'         => array(
						'required' => true,
						'type'     => 'string',
					),
					'health_paths' => $paths_arg,
				),
			)
		);

		register_rest_route(
			$ns,
			'/loopback',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'loopback' ),
				'permission_callback' => $permission,
				'args'                => array( 'health_paths' => $paths_arg ),
			)
		);

		register_rest_route(
			$ns,
			'/backups',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'backups' ),
				'permission_callback' => $permission,
			)
		);

		$snapshot_id = array(
			'type'    => 'string',
			'pattern' => '^\d{8}-\d{6}-[a-z0-9]{8}$',
		);

		register_rest_route(
			$ns,
			'/db/snapshot',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'db_snapshot' ),
				'permission_callback' => $permission,
				'args'                => array(
					'snapshot_id' => $snapshot_id,
					'label'       => array(
						'type'    => 'string',
						'default' => '',
					),
					'exclude'     => array(
						'type'    => 'array',
						'items'   => array( 'type' => 'string' ),
						'default' => array(),
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/inventory',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'inventory' ),
				'permission_callback' => $permission,
			)
		);

		register_rest_route(
			$ns,
			'/diagnostics/files',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'file_scan' ),
				'permission_callback' => $permission,
				'args'                => array(
					'scan_id' => array(
						'type'    => 'string',
						'default' => '',
					),
					'depth'   => array(
						'type'    => 'integer',
						'default' => 2,
					),
					'path'    => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/diagnostics/malware',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'malware_scan' ),
				'permission_callback' => $permission,
				'args'                => array(
					'scan_id' => array(
						'type'    => 'string',
						'default' => '',
					),
					'path'    => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/diagnostics/file',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'read_file' ),
				'permission_callback' => $permission,
				'args'                => array(
					'path'  => array(
						'required' => true,
						'type'     => 'string',
					),
					'bytes' => array(
						'type'    => 'integer',
						'default' => 65536,
					),
				),
			)
		);

		// Bajo /rescue/ para poder consultar el estado de una restauración con el sitio caído.
		register_rest_route(
			$ns,
			'/rescue/db-snapshots',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'db_snapshots' ),
				'permission_callback' => $permission,
			)
		);

		register_rest_route(
			$ns,
			'/db/delete',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'db_delete' ),
				'permission_callback' => $permission,
				'args'                => array( 'snapshot_id' => array_merge( $snapshot_id, array( 'required' => true ) ) ),
			)
		);

		register_rest_route(
			$ns,
			'/rescue/db-restore',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'db_restore' ),
				'permission_callback' => $permission,
				'args'                => array( 'snapshot_id' => array_merge( $snapshot_id, array( 'required' => true ) ) ),
			)
		);

		// Ruta de rescate: la guardia en mu-plugins la reconoce por el prefijo /rescue/.
		register_rest_route(
			$ns,
			'/rescue/rollback',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'rollback' ),
				'permission_callback' => $permission,
				'args'                => array(
					'backup_id'    => array(
						'required' => true,
						'type'     => 'string',
						'pattern'  => '^\d{8}-\d{6}-[a-z0-9]{8}$',
					),
					'force'        => array(
						'type'    => 'boolean',
						'default' => false,
					),
					'health_paths' => $paths_arg,
				),
			)
		);
	}

	public static function permission( WP_REST_Request $request ) {
		if ( ! OneBit_WPM_Token::is_configured() ) {
			return new WP_Error( 'onebit_wpm_no_token', 'Falta generar el token en Herramientas > 1Bit Maintenance.', array( 'status' => 503 ) );
		}

		if ( ! OneBit_WPM_Token::verify( $request->get_header( 'x_1bit_token' ) ) ) {
			return new WP_Error( 'onebit_wpm_bad_token', 'Token inválido.', array( 'status' => 403 ) );
		}

		if ( ! is_user_logged_in() ) {
			return new WP_Error( 'onebit_wpm_no_auth', 'Falta autenticación: usá una contraseña de aplicación.', array( 'status' => 401 ) );
		}

		if ( ! current_user_can( 'update_plugins' ) && ! current_user_can( 'update_themes' ) ) {
			return new WP_Error( 'onebit_wpm_forbidden', 'El usuario no tiene permisos para actualizar.', array( 'status' => 403 ) );
		}

		return true;
	}

	public static function db_snapshot( WP_REST_Request $request ) {
		$token = (string) $request->get_header( 'x_1bit_token' );
		$id    = $request['snapshot_id'];

		if ( ! $id ) {
			$manifest = OneBit_WPM_Db_Snapshots::start( $token, $request['label'], $request['exclude'] );
			if ( is_wp_error( $manifest ) ) {
				return $manifest;
			}
			$id = $manifest['snapshot_id'];
		}

		return rest_ensure_response( OneBit_WPM_Db_Snapshots::step( $id, $token ) );
	}

	public static function inventory() {
		return rest_ensure_response( OneBit_WPM_Updater::inventory() );
	}

	public static function file_scan( WP_REST_Request $request ) {
		return rest_ensure_response( OneBit_WPM_Diagnostics::file_scan( $request['scan_id'], $request['depth'], $request['path'] ) );
	}

	public static function malware_scan( WP_REST_Request $request ) {
		return rest_ensure_response( OneBit_WPM_Malware::scan( $request['scan_id'], $request['path'] ) );
	}

	public static function read_file( WP_REST_Request $request ) {
		// Leer archivos del servidor es cosa de administrador, no de quien solo actualiza.
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'onebit_wpm_forbidden', 'Leer archivos requiere un usuario administrador.', array( 'status' => 403 ) );
		}

		return rest_ensure_response( OneBit_WPM_Malware::read( $request['path'], $request['bytes'] ) );
	}

	public static function db_snapshots() {
		return rest_ensure_response(
			array(
				'snapshots'       => OneBit_WPM_Db_Snapshots::all(),
				'retention_hours' => OneBit_WPM_Db_Snapshots::retention_hours(),
				'keep'            => OneBit_WPM_Db_Snapshots::keep(),
			)
		);
	}

	public static function db_delete( WP_REST_Request $request ) {
		$result = OneBit_WPM_Db_Snapshots::delete( $request['snapshot_id'] );
		return is_wp_error( $result ) ? $result : rest_ensure_response( array( 'deleted' => $request['snapshot_id'] ) );
	}

	public static function db_restore( WP_REST_Request $request ) {
		// Pisar la base entera exige más que permisos de actualización.
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'onebit_wpm_forbidden', 'Restaurar la base requiere un usuario administrador.', array( 'status' => 403 ) );
		}

		return rest_ensure_response( OneBit_WPM_Db_Snapshots::restore_step( $request['snapshot_id'], (string) $request->get_header( 'x_1bit_token' ) ) );
	}

	public static function status( WP_REST_Request $request ) {
		OneBit_WPM_Guard::ensure();
		OneBit_WPM_Plugin::ensure_schedules();
		OneBit_WPM_Db_Snapshots::prune();

		$pending = OneBit_WPM_Updater::pending( (bool) $request['refresh'] );

		return rest_ensure_response(
			array_merge(
				OneBit_WPM_Updater::environment(),
				array(
					'site_url'    => home_url(),
					'core_update' => $pending['core_update'],
					'items'       => $pending['items'],
				)
			)
		);
	}

	public static function update( WP_REST_Request $request ) {
		$type = $request['type'];
		$cap  = ( 'plugin' === $type ) ? 'update_plugins' : 'update_themes';

		if ( ! current_user_can( $cap ) ) {
			return new WP_Error( 'onebit_wpm_forbidden', 'El usuario no tiene permisos para este tipo de actualización.', array( 'status' => 403 ) );
		}

		$result = OneBit_WPM_Updater::update( $type, $request['item'], $request['health_paths'] );

		OneBit_WPM_Backups::prune( OneBit_WPM_Plugin::retention_days() );

		return rest_ensure_response( $result );
	}

	public static function loopback( WP_REST_Request $request ) {
		return rest_ensure_response( OneBit_WPM_Health::loopback( $request['health_paths'] ) );
	}

	public static function backups() {
		return rest_ensure_response( array( 'backups' => OneBit_WPM_Backups::all() ) );
	}

	public static function rollback( WP_REST_Request $request ) {
		$result = OneBit_WPM_Updater::rollback( $request['backup_id'], (bool) $request['force'] );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$result['rescue_mode'] = defined( 'ONEBIT_WPM_RESCUE' );
		// El loopback es una petición normal, sin cabecera de rescate: refleja el estado real del sitio.
		$result['loopback'] = OneBit_WPM_Health::loopback( $request['health_paths'] );

		return rest_ensure_response( $result );
	}
}
