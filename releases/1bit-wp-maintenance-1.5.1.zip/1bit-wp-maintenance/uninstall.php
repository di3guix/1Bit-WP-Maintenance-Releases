<?php
/**
 * Desinstalación: borra la guardia, los backups, los snapshots de base y las opciones.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

$onebit_wpm_guard = WPMU_PLUGIN_DIR . '/1bit-wp-maintenance-guard.php';
if ( file_exists( $onebit_wpm_guard ) ) {
	// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
	@unlink( $onebit_wpm_guard );
}

$onebit_wpm_dir_name = get_option( 'onebit_wpm_backup_dir' );

// Validación estricta del nombre: un valor corrupto nunca debe apuntar a uploads entero.
// Los snapshots de base viven dentro de esta misma carpeta.
if ( is_string( $onebit_wpm_dir_name ) && preg_match( '/^1bit-wpm-[a-z0-9]{16}$/', $onebit_wpm_dir_name ) ) {
	require_once __DIR__ . '/includes/class-onebit-wpm-backups.php';

	$onebit_wpm_uploads = wp_upload_dir( null, false );
	OneBit_WPM_Backups::rrmdir( trailingslashit( $onebit_wpm_uploads['basedir'] ) . $onebit_wpm_dir_name );
}

// Tablas temporales de una restauración interrumpida.
foreach ( array( 'wpmrs_', 'wpmro_' ) as $onebit_wpm_tag ) {
	$onebit_wpm_tables = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->prefix . $onebit_wpm_tag ) . '%' ) );
	foreach ( (array) $onebit_wpm_tables as $onebit_wpm_table ) {
		$wpdb->query( 'DROP TABLE IF EXISTS `' . str_replace( '`', '``', $onebit_wpm_table ) . '`' ); // phpcs:ignore WordPress.DB
	}
}

$onebit_wpm_options = array(
	'onebit_wpm_token_hash',
	'onebit_wpm_backup_dir',
	'onebit_wpm_log',
	'onebit_wpm_lock',
	'onebit_wpm_retention_days',
	'onebit_wpm_last_loopback',
	'onebit_wpm_db_retention_hours',
	'onebit_wpm_db_keep',
);

foreach ( $onebit_wpm_options as $onebit_wpm_option ) {
	delete_option( $onebit_wpm_option );
}

wp_clear_scheduled_hook( 'onebit_wpm_daily' );
wp_clear_scheduled_hook( 'onebit_wpm_hourly' );
