<?php
/**
 * Diagnóstico de por qué no están disponibles las contraseñas de aplicación.
 *
 * WordPress las oculta sin explicar el motivo. Las causas habituales son que no
 * detecte HTTPS (proxies y CDNs) o que un plugin, el tema o un snippet las apague
 * con el filtro wp_is_application_passwords_available.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Diagnostics {

	const FILTERS       = array( 'wp_is_application_passwords_available', 'wp_is_application_passwords_available_for_user' );
	const SCAN_SECONDS  = 20;
	const MAX_MATCHES   = 40;
	const FSCAN_SECONDS = 20;
	const FSCAN_GROUPS  = 60;

	/**
	 * Cuenta archivos y carpetas del sitio, agrupando por carpeta.
	 *
	 * Los hostings limitan la cantidad de archivos (inodos) y avisan cuando se pasa.
	 * Recorre por partes: cada llamada trabaja unos segundos y guarda por dónde iba,
	 * así una instalación con cientos de miles de archivos no corta PHP por tiempo.
	 *
	 * @param string $scan_id Recorrido en curso, vacío para empezar uno nuevo.
	 * @param int    $depth   Cuántos niveles de carpeta agrupar (1 a 4).
	 * @param string $path    Carpeta desde donde contar, relativa a WordPress (vacío: todo el sitio).
	 * @return array|WP_Error
	 */
	public static function file_scan( $scan_id = '', $depth = 2, $path = '' ) {
		$root  = untrailingslashit( wp_normalize_path( ABSPATH ) );
		$clean = preg_replace( '/[^a-z0-9]/', '', strtolower( (string) $scan_id ) );
		$state = $clean ? get_transient( 'onebit_wpm_fscan_' . $clean ) : false;

		if ( ! is_array( $state ) ) {
			$start = trim( wp_normalize_path( (string) $path ), '/' );
			if ( '' !== $start && ( validate_file( $start ) || ! is_dir( $root . '/' . $start ) ) ) {
				return new WP_Error( 'onebit_wpm_bad_path', sprintf( 'No existe la carpeta %s.', $start ), array( 'status' => 400 ) );
			}

			$clean = strtolower( wp_generate_password( 8, false, false ) );
			$state = array(
				'stack'  => array( $start ),  // rutas relativas a la raíz de WordPress
				'groups' => array(),
				'types'  => array(),
				'files'  => 0,
				'dirs'   => 0,
				'depth'  => max( 1, min( 5, (int) $depth ) ),
			);
		}

		$deadline = microtime( true ) + self::FSCAN_SECONDS;

		while ( $state['stack'] && microtime( true ) < $deadline ) {
			$relative = array_pop( $state['stack'] );
			$dir      = $relative ? $root . '/' . $relative : $root;
			$handle   = @opendir( $dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions

			if ( ! $handle ) {
				continue;
			}

			$group = self::group_for( $relative, $state['depth'] );

			while ( false !== ( $entry = readdir( $handle ) ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
				if ( '.' === $entry || '..' === $entry ) {
					continue;
				}

				$child = $relative ? $relative . '/' . $entry : $entry;
				$path  = $root . '/' . $child;

				// Los enlaces simbólicos no se siguen: contarían de nuevo lo mismo.
				if ( is_link( $path ) ) {
					continue;
				}

				if ( is_dir( $path ) ) {
					$state['stack'][] = $child;
					$state['dirs']++;
					continue;
				}

				$size = (int) @filesize( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				$type = self::file_type( $entry );

				$state['files']++;
				if ( ! isset( $state['groups'][ $group ] ) ) {
					$state['groups'][ $group ] = array( 'files' => 0, 'bytes' => 0 );
				}
				$state['groups'][ $group ]['files']++;
				$state['groups'][ $group ]['bytes'] += $size;

				if ( ! isset( $state['types'][ $type ] ) ) {
					$state['types'][ $type ] = array( 'files' => 0, 'bytes' => 0 );
				}
				$state['types'][ $type ]['files']++;
				$state['types'][ $type ]['bytes'] += $size;
			}

			closedir( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		$done = empty( $state['stack'] );
		set_transient( 'onebit_wpm_fscan_' . $clean, $state, 30 * MINUTE_IN_SECONDS );

		$groups = $state['groups'];
		uasort(
			$groups,
			function ( $a, $b ) {
				return $b['files'] <=> $a['files'];
			}
		);

		$top = array();
		foreach ( array_slice( $groups, 0, self::FSCAN_GROUPS, true ) as $name => $data ) {
			$top[] = array( 'path' => $name, 'files' => $data['files'], 'bytes' => $data['bytes'] );
		}

		return array(
			'scan_id'      => $clean,
			'done'         => $done,
			'files'        => $state['files'],
			'dirs'         => $state['dirs'],
			'pending_dirs' => count( $state['stack'] ),
			'groups'       => $top,
			'types'        => isset( $state['types'] ) ? $state['types'] : array(),
		);
	}

	/**
	 * Qué es un archivo, por su nombre. El orden importa: un "foto-300x300.jpg.webp" es un
	 * WebP generado, no una miniatura.
	 */
	private static function file_type( $name ) {
		$name = strtolower( $name );

		// Los index.php vacíos y .htaccess que dejan los plugins para proteger carpetas no son sospechosos.
		if ( in_array( $name, array( 'index.php', 'index.html', '.htaccess', 'web.config' ), true ) ) {
			return 'protección de carpeta (index.php/.htaccess)';
		}
		if ( preg_match( '/\.bk\.(jpe?g|png|gif|webp)$/', $name ) ) {
			return 'backup de original (optimizador de imágenes)';
		}
		if ( substr( $name, -5 ) === '.avif' ) {
			return 'AVIF generado';
		}
		if ( substr( $name, -5 ) === '.webp' ) {
			return preg_match( '/\.(jpe?g|png|gif)\.webp$/', $name ) ? 'WebP generado' : 'WebP';
		}
		if ( preg_match( '/-\d+x\d+\.(jpe?g|png|gif)$/', $name ) ) {
			return 'miniatura';
		}
		if ( preg_match( '/-scaled\.(jpe?g|png|gif)$/', $name ) ) {
			return 'imagen reducida (-scaled)';
		}
		if ( preg_match( '/\.(jpe?g|png|gif|svg|bmp|tiff?)$/', $name ) ) {
			return 'imagen original';
		}
		if ( preg_match( '/\.(php|phtml|phar)\d*$/', $name ) ) {
			return 'php';
		}
		if ( preg_match( '/\.(css|js)$/', $name ) ) {
			return 'css/js';
		}
		if ( preg_match( '/\.(log|txt)$/', $name ) ) {
			return 'log/texto';
		}
		if ( preg_match( '/\.(zip|gz|tar|sql|bak|wpress)$/', $name ) ) {
			return 'backup/comprimido';
		}
		if ( preg_match( '/\.(mp4|mov|webm|mp3|pdf|docx?|xlsx?)$/', $name ) ) {
			return 'video/documento';
		}

		return 'otros';
	}

	private static function group_for( $relative, $depth ) {
		if ( '' === $relative ) {
			return '(raíz de WordPress)';
		}

		$parts = explode( '/', $relative );

		return implode( '/', array_slice( $parts, 0, $depth ) );
	}

	/**
	 * Chequeos rápidos, sin leer archivos.
	 *
	 * @return array{available: bool, ssl: bool, supported: bool, environment: string, callbacks: array, https_hints: array}
	 */
	public static function application_passwords() {
		$callbacks = array();

		foreach ( self::FILTERS as $hook ) {
			if ( empty( $GLOBALS['wp_filter'][ $hook ] ) ) {
				continue;
			}
			foreach ( $GLOBALS['wp_filter'][ $hook ]->callbacks as $priority => $items ) {
				foreach ( $items as $item ) {
					$callbacks[] = array_merge( array( 'hook' => $hook, 'priority' => $priority ), self::describe( $item['function'] ) );
				}
			}
		}

		// Pistas de un proxy que termina el SSL sin avisarle a PHP.
		$hints = array();
		foreach ( array( 'HTTP_X_FORWARDED_PROTO', 'HTTP_X_FORWARDED_SSL', 'HTTP_CF_VISITOR', 'HTTPS', 'SERVER_PORT' ) as $key ) {
			if ( isset( $_SERVER[ $key ] ) ) {
				$hints[ $key ] = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
			}
		}

		return array(
			'available'   => wp_is_application_passwords_available(),
			'ssl'         => is_ssl(),
			'supported'   => wp_is_application_passwords_supported(),
			'environment' => wp_get_environment_type(),
			'callbacks'   => $callbacks,
			'https_hints' => $hints,
		);
	}

	/**
	 * Busca el código que las desactiva en archivos y en snippets guardados en la base.
	 */
	public static function scan() {
		$started = microtime( true );
		$matches = array();
		$self    = wp_normalize_path( ONEBIT_WPM_DIR );
		$roots   = array_unique( array_filter( array( WP_PLUGIN_DIR, WPMU_PLUGIN_DIR, get_theme_root() ), 'is_dir' ) );
		$files   = 0;
		$partial = false;

		foreach ( $roots as $root ) {
			$iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, RecursiveDirectoryIterator::SKIP_DOTS ) );

			foreach ( $iterator as $file ) {
				if ( microtime( true ) - $started > self::SCAN_SECONDS || count( $matches ) >= self::MAX_MATCHES ) {
					$partial = true;
					break 2;
				}

				$path = wp_normalize_path( $file->getPathname() );
				if ( 'php' !== strtolower( $file->getExtension() ) || 0 === strpos( $path, $self ) || $file->getSize() > 2 * MB_IN_BYTES ) {
					continue;
				}

				$files++;
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				$content = @file_get_contents( $path );
				if ( false === $content || false === stripos( $content, 'application_password' ) ) {
					continue;
				}

				foreach ( preg_split( '/\R/', $content ) as $number => $line ) {
					if ( false !== stripos( $line, 'application_password' ) && preg_match( '/add_filter|__return_false|disable|remove_|_available/i', $line ) ) {
						$matches[] = array(
							'where' => self::component( $path ),
							'file'  => str_replace( wp_normalize_path( WP_CONTENT_DIR ), 'wp-content', $path ),
							'line'  => $number + 1,
							'code'  => mb_substr( trim( $line ), 0, 180 ),
						);
					}
				}
			}
		}

		return array(
			'matches'  => $matches,
			'snippets' => self::snippets(),
			'settings' => self::security_settings(),
			'files'    => $files,
			'partial'  => $partial,
			'seconds'  => round( microtime( true ) - $started, 1 ),
		);
	}

	/**
	 * Snippets de Code Snippets y WPCode, que viven en la base y no en archivos.
	 */
	private static function snippets() {
		global $wpdb;
		$found = array();

		$table = $wpdb->prefix . 'snippets';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
			$rows = $wpdb->get_results( "SELECT id, name, active FROM `{$table}` WHERE code LIKE '%application_password%'", ARRAY_A ); // phpcs:ignore WordPress.DB
			foreach ( (array) $rows as $row ) {
				$found[] = sprintf( 'Code Snippets #%d "%s" (%s)', $row['id'], $row['name'], $row['active'] ? 'activo' : 'inactivo' );
			}
		}

		$posts = $wpdb->get_results(
			"SELECT ID, post_title, post_status, post_type FROM {$wpdb->posts} WHERE post_type IN ('wpcode', 'wpcode_snippet') AND post_content LIKE '%application_password%'", // phpcs:ignore WordPress.DB
			ARRAY_A
		);
		foreach ( (array) $posts as $post ) {
			$found[] = sprintf( 'WPCode #%d "%s" (%s)', $post['ID'], $post['post_title'], $post['post_status'] );
		}

		return $found;
	}

	/**
	 * Ajustes guardados de plugins de seguridad que tocan las contraseñas de aplicación.
	 */
	private static function security_settings() {
		global $wpdb;
		$found = array();

		// Wordfence Login Security guarda sus ajustes en su propia tabla.
		$table = $wpdb->base_prefix . 'wfls_settings';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
			$rows = $wpdb->get_results( "SELECT name, value FROM `{$table}` WHERE name LIKE '%application%'", ARRAY_A ); // phpcs:ignore WordPress.DB
			foreach ( (array) $rows as $row ) {
				$found[] = sprintf( 'Wordfence Login Security: %s = %s', $row['name'], $row['value'] );
			}
		}

		$options = $wpdb->get_results(
			"SELECT option_name FROM {$wpdb->options} WHERE option_value LIKE '%application_password%' AND option_name NOT LIKE '\\_transient%' AND option_name NOT LIKE '\\_site\\_transient%' AND option_name NOT LIKE 'onebit\\_wpm%' LIMIT 20", // phpcs:ignore WordPress.DB
			ARRAY_A
		);
		foreach ( (array) $options as $option ) {
			$found[] = sprintf( 'Opción "%s" menciona las contraseñas de aplicación', $option['option_name'] );
		}

		return $found;
	}

	private static function describe( $callback ) {
		$name = 'desconocido';
		$file = '';

		try {
			if ( is_string( $callback ) && false !== strpos( $callback, '::' ) ) {
				$name = $callback;
				$file = ( new ReflectionMethod( $callback ) )->getFileName();
			} elseif ( is_string( $callback ) ) {
				$name = $callback;
				$file = ( new ReflectionFunction( $callback ) )->getFileName();
			} elseif ( $callback instanceof Closure ) {
				$name = 'función anónima';
				$file = ( new ReflectionFunction( $callback ) )->getFileName();
			} elseif ( is_array( $callback ) && 2 === count( $callback ) ) {
				$class = is_object( $callback[0] ) ? get_class( $callback[0] ) : (string) $callback[0];
				$name  = $class . '::' . $callback[1];
				$file  = ( new ReflectionMethod( $class, $callback[1] ) )->getFileName();
			}
		} catch ( ReflectionException $e ) {
			$file = '';
		}

		$file = $file ? wp_normalize_path( $file ) : '';

		// __return_false vive en el core: quién lo agregó no se puede saber por reflexión.
		$generic = $file && 0 === strpos( $file, wp_normalize_path( ABSPATH . WPINC ) );

		return array(
			'callback' => $name,
			'where'    => $generic ? 'agregado por un plugin, el tema o un snippet (ver la búsqueda)' : ( $file ? self::component( $file ) : 'desconocido' ),
			'file'     => $file ? str_replace( wp_normalize_path( ABSPATH ), '', $file ) : '',
		);
	}

	private static function component( $path ) {
		$path = wp_normalize_path( $path );

		foreach ( array( 'plugin' => WP_PLUGIN_DIR, 'mu-plugin' => WPMU_PLUGIN_DIR, 'tema' => get_theme_root() ) as $type => $root ) {
			$root = trailingslashit( wp_normalize_path( $root ) );
			if ( 0 === strpos( $path, $root ) ) {
				$slug = strtok( substr( $path, strlen( $root ) ), '/' );
				return "{$type} {$slug}";
			}
		}

		return 0 === strpos( $path, wp_normalize_path( ABSPATH . WPINC ) ) ? 'core de WordPress' : 'otro';
	}
}
