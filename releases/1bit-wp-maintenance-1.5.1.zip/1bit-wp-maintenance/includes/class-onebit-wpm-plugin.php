<?php
/**
 * Arranque, activación y tareas programadas.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Plugin {

	const CRON_HOOK         = 'onebit_wpm_daily';
	const HOURLY_HOOK       = 'onebit_wpm_hourly';
	const RETENTION_OPTION  = 'onebit_wpm_retention_days';
	const DEFAULT_RETENTION = 14;

	public static function boot() {
		add_action( 'rest_api_init', array( 'OneBit_WPM_Rest', 'register_routes' ) );
		OneBit_WPM_Self_Update::boot();
		add_action( self::CRON_HOOK, array( __CLASS__, 'daily' ) );
		add_action( self::HOURLY_HOOK, array( __CLASS__, 'hourly' ) );

		if ( is_admin() ) {
			OneBit_WPM_Admin::boot();
		}
	}

	public static function activate() {
		OneBit_WPM_Backups::base_dir();
		OneBit_WPM_Guard::install();
		self::ensure_schedules();

		OneBit_WPM_Log::add( 'info', 'Plugin activado.' );
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
		wp_clear_scheduled_hook( self::HOURLY_HOOK );
		OneBit_WPM_Guard::remove();
		delete_option( OneBit_WPM_Updater::LOCK_OPTION );
	}

	/**
	 * También cubre sitios que actualizaron el plugin sin reactivarlo.
	 */
	public static function ensure_schedules() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
		if ( ! wp_next_scheduled( self::HOURLY_HOOK ) ) {
			wp_schedule_event( time() + 5 * MINUTE_IN_SECONDS, 'hourly', self::HOURLY_HOOK );
		}
	}

	/**
	 * Limpieza diaria de backups de archivos y autorreparación de la guardia.
	 */
	public static function daily() {
		$deleted = OneBit_WPM_Backups::prune( self::retention_days() );
		if ( $deleted ) {
			OneBit_WPM_Log::add( 'info', sprintf( 'Se eliminaron %d backup(s) vencidos.', $deleted ) );
		}
		OneBit_WPM_Guard::ensure();
	}

	/**
	 * Los snapshots de base contienen datos personales: se borran apenas vencen.
	 */
	public static function hourly() {
		$deleted = OneBit_WPM_Db_Snapshots::prune();
		if ( $deleted ) {
			OneBit_WPM_Log::add( 'info', sprintf( 'Se eliminaron %d snapshot(s) de base vencidos.', $deleted ) );
		}
	}

	public static function retention_days() {
		return max( 1, (int) get_option( self::RETENTION_OPTION, self::DEFAULT_RETENTION ) );
	}
}
