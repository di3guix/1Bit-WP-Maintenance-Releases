<?php
/**
 * Cifrado de los snapshots de base de datos.
 *
 * La clave se deriva del token del orquestador, que en el servidor solo existe
 * como hash: un snapshot descargado del sitio no se puede leer sin el token.
 *
 * Formato de cada bloque: longitud (4 bytes, big-endian) + IV (12) + tag (16) + datos.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Crypto {

	const CIPHER  = 'aes-256-gcm';
	const IV_LEN  = 12;
	const TAG_LEN = 16;

	public static function available() {
		return function_exists( 'openssl_encrypt' )
			&& in_array( self::CIPHER, array_map( 'strtolower', openssl_get_cipher_methods() ), true );
	}

	/**
	 * Clave distinta por snapshot, derivada del token.
	 */
	public static function key( $token, $snapshot_id ) {
		return hash_hmac( 'sha256', 'onebit-wpm-db|' . $snapshot_id, (string) $token, true );
	}

	/**
	 * Valor para verificar que el token es el correcto sin guardar la clave.
	 */
	public static function key_check( $key ) {
		return hash_hmac( 'sha256', 'onebit-wpm-key-check', $key );
	}

	/**
	 * @return string|false Bloque listo para escribir en disco.
	 */
	public static function seal( $plaintext, $key ) {
		$iv  = random_bytes( self::IV_LEN );
		$tag = '';
		$ct  = openssl_encrypt( $plaintext, self::CIPHER, $key, OPENSSL_RAW_DATA, $iv, $tag, '', self::TAG_LEN );

		if ( false === $ct ) {
			return false;
		}

		$payload = $iv . $tag . $ct;

		return pack( 'N', strlen( $payload ) ) . $payload;
	}

	/**
	 * @param string $payload Bloque sin los 4 bytes de longitud.
	 * @return string|false Texto plano, o false si el bloque fue alterado o la clave no corresponde.
	 */
	public static function open( $payload, $key ) {
		if ( strlen( $payload ) < self::IV_LEN + self::TAG_LEN ) {
			return false;
		}

		return openssl_decrypt(
			substr( $payload, self::IV_LEN + self::TAG_LEN ),
			self::CIPHER,
			$key,
			OPENSSL_RAW_DATA,
			substr( $payload, 0, self::IV_LEN ),
			substr( $payload, self::IV_LEN, self::TAG_LEN )
		);
	}
}
