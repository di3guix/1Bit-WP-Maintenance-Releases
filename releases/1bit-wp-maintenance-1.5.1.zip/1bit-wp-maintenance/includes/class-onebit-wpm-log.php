<?php
/**
 * Registro de eventos, visible desde el panel del plugin.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Log {

	const OPTION = 'onebit_wpm_log';
	const MAX    = 200;

	/**
	 * @param string $level   info | warning | error
	 * @param string $message Mensaje legible.
	 * @param array  $context Datos extra.
	 */
	public static function add( $level, $message, $context = array() ) {
		$entries = get_option( self::OPTION, array() );
		if ( ! is_array( $entries ) ) {
			$entries = array();
		}

		array_unshift(
			$entries,
			array(
				'time'    => time(),
				'level'   => $level,
				'message' => $message,
				'context' => $context,
			)
		);

		update_option( self::OPTION, array_slice( $entries, 0, self::MAX ), false );
	}

	public static function all( $limit = 50 ) {
		$entries = get_option( self::OPTION, array() );
		return is_array( $entries ) ? array_slice( $entries, 0, $limit ) : array();
	}
}
