<?php
/**
 * Snapshots cifrados de la base de datos y su restauración.
 *
 * Exportación y restauración avanzan por pasos cortos (varias peticiones), para
 * no chocar con el tiempo máximo de ejecución del hosting en bases grandes.
 *
 * La restauración carga los datos en tablas temporales y recién al final las
 * intercambia con las reales en un único RENAME TABLE, que es atómico: si algo
 * falla antes, la base en uso no se tocó.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Db_Snapshots {

	const ID_PATTERN        = '/^\d{8}-\d{6}-[a-z0-9]{8}$/';
	const RETENTION_OPTION  = 'onebit_wpm_db_retention_hours';
	const KEEP_OPTION       = 'onebit_wpm_db_keep';
	const DEFAULT_RETENTION = 48;
	const MAX_RETENTION     = 168;
	const DEFAULT_KEEP      = 3;
	const MAX_KEEP          = 10;
	const BATCH_ROWS        = 200;
	const CHUNK_BYTES       = 524288;
	const ABANDONED_SECONDS = 10800;
	const TEMP_TAG          = 'wpmrs_';
	const OLD_TAG           = 'wpmro_';

	/**
	 * Opciones del propio plugin que no deben volver atrás al restaurar: sin ellas
	 * el orquestador perdería el acceso o quedaría un candado viejo.
	 */
	const PRESERVED_OPTIONS = array(
		'onebit_wpm_token_hash',
		'onebit_wpm_backup_dir',
		'onebit_wpm_log',
		'onebit_wpm_retention_days',
		'onebit_wpm_db_retention_hours',
		'onebit_wpm_db_keep',
		'onebit_wpm_last_loopback',
	);

	// ------------------------------------------------------------------ config

	public static function retention_hours() {
		return max( 1, min( self::MAX_RETENTION, (int) get_option( self::RETENTION_OPTION, self::DEFAULT_RETENTION ) ) );
	}

	public static function keep() {
		return max( 1, min( self::MAX_KEEP, (int) get_option( self::KEEP_OPTION, self::DEFAULT_KEEP ) ) );
	}

	/**
	 * @return string|null Motivo por el que no se pueden tomar snapshots, o null si se puede.
	 */
	public static function unavailable_reason() {
		if ( is_multisite() ) {
			return 'no disponible en instalaciones multisitio';
		}
		if ( ! OneBit_WPM_Crypto::available() ) {
			return 'PHP no tiene OpenSSL con AES-256-GCM';
		}
		return null;
	}

	private static function dir() {
		$dir = OneBit_WPM_Backups::base_dir() . '/db';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		OneBit_WPM_Backups::protect( $dir );
		return $dir;
	}

	private static function budget() {
		$budget = 20;
		$max    = (int) ini_get( 'max_execution_time' );
		if ( $max > 0 ) {
			$budget = min( $budget, max( 3, (int) floor( $max / 2 ) ) );
		}

		/** Segundos de trabajo por petición. */
		return (float) apply_filters( 'onebit_wpm_db_step_seconds', $budget );
	}

	// ------------------------------------------------------------------ tablas

	private static function quote( $name ) {
		return '`' . str_replace( '`', '``', $name ) . '`';
	}

	/**
	 * Tablas de este sitio con su tamaño estimado.
	 *
	 * Si en la misma base hay otra instalación cuyo prefijo empieza igual (wp_ y
	 * wp_tienda_, por ejemplo), sus tablas se excluyen: restaurar nunca debe tocar
	 * otro sitio.
	 */
	public static function tables() {
		global $wpdb;

		$rows = $wpdb->get_results( $wpdb->prepare( 'SHOW TABLE STATUS LIKE %s', $wpdb->esc_like( $wpdb->prefix ) . '%' ), ARRAY_A );

		$all = array();
		foreach ( (array) $rows as $row ) {
			// Las vistas no tienen motor.
			if ( empty( $row['Engine'] ) ) {
				continue;
			}
			$all[ $row['Name'] ] = array(
				'rows'  => (int) $row['Rows'],
				'bytes' => (int) $row['Data_length'] + (int) $row['Index_length'],
			);
		}

		$foreign = array();
		foreach ( array_keys( $all ) as $name ) {
			if ( $name !== $wpdb->options && 'options' === substr( $name, -7 ) ) {
				$other = substr( $name, 0, -7 );
				if ( isset( $all[ $other . 'posts' ] ) ) {
					$foreign[] = $other;
				}
			}
		}

		$out = array();
		foreach ( $all as $name => $info ) {
			if ( false !== strpos( $name, $wpdb->prefix . self::TEMP_TAG ) || false !== strpos( $name, $wpdb->prefix . self::OLD_TAG ) ) {
				continue;
			}
			foreach ( $foreign as $other ) {
				if ( 0 === strpos( $name, $other ) ) {
					continue 2;
				}
			}
			$out[ $name ] = $info;
		}

		return $out;
	}

	public static function database_bytes() {
		return array_sum( wp_list_pluck( self::tables(), 'bytes' ) );
	}

	private static function temp_name( $id, $table ) {
		global $wpdb;
		return $wpdb->prefix . self::TEMP_TAG . substr( md5( $id . '|' . $table ), 0, 16 );
	}

	private static function old_name( $id, $table ) {
		global $wpdb;
		return $wpdb->prefix . self::OLD_TAG . substr( md5( $id . '|' . $table ), 0, 16 );
	}

	/**
	 * Columna para paginar por clave (rápido en tablas grandes) u orden estable para OFFSET.
	 */
	private static function pagination( $table ) {
		global $wpdb;

		$keys = $wpdb->get_results( 'SHOW KEYS FROM ' . self::quote( $table ) . " WHERE Key_name = 'PRIMARY'", ARRAY_A );
		$cols = array();
		foreach ( (array) $keys as $key ) {
			$cols[ (int) $key['Seq_in_index'] ] = $key['Column_name'];
		}
		ksort( $cols );
		$cols = array_values( $cols );

		$keyset = null;
		if ( 1 === count( $cols ) ) {
			$column = $wpdb->get_row( 'SHOW COLUMNS FROM ' . self::quote( $table ) . ' LIKE ' . "'" . esc_sql( $wpdb->esc_like( $cols[0] ) ) . "'", ARRAY_A );
			if ( $column && preg_match( '/int/i', $column['Type'] ) ) {
				$keyset = $cols[0];
			}
		}

		return array(
			'keyset' => $keyset,
			'order'  => $cols,
		);
	}

	/**
	 * Ejecuta SQL directo sobre la conexión, sin los filtros de wpdb que reescriben
	 * texto no ASCII: el contenido tiene que llegar byte por byte.
	 */
	private static function exec( $sql ) {
		global $wpdb;

		$dbh = $wpdb->dbh;

		if ( $dbh instanceof mysqli ) {
			if ( ! mysqli_query( $dbh, $sql ) ) {
				throw new RuntimeException( mysqli_error( $dbh ) );
			}
			return;
		}

		if ( false === $wpdb->query( $sql ) || $wpdb->last_error ) {
			throw new RuntimeException( $wpdb->last_error ? $wpdb->last_error : 'consulta fallida' );
		}
	}

	private static function escape( $value ) {
		global $wpdb;

		if ( $wpdb->dbh instanceof mysqli ) {
			return mysqli_real_escape_string( $wpdb->dbh, $value );
		}

		return addslashes( $value );
	}

	// ------------------------------------------------------------------ manifiestos

	private static function manifest_path( $id ) {
		return self::dir() . '/' . $id . '/manifest.json';
	}

	private static function data_path( $id ) {
		return self::dir() . '/' . $id . '/snapshot.bin';
	}

	private static function save( array $manifest ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		file_put_contents( self::manifest_path( $manifest['snapshot_id'] ), wp_json_encode( $manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ), LOCK_EX );
	}

	/**
	 * @return array|WP_Error
	 */
	private static function get( $id ) {
		if ( ! is_string( $id ) || ! preg_match( self::ID_PATTERN, $id ) ) {
			return new WP_Error( 'onebit_wpm_db_bad_id', 'Identificador de snapshot inválido.', array( 'status' => 400 ) );
		}

		$path = self::manifest_path( $id );
		if ( ! file_exists( $path ) ) {
			return new WP_Error( 'onebit_wpm_db_not_found', sprintf( 'No existe el snapshot %s (puede haber vencido).', $id ), array( 'status' => 404 ) );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$manifest = json_decode( (string) file_get_contents( $path ), true );

		return is_array( $manifest ) ? $manifest : new WP_Error( 'onebit_wpm_db_bad_manifest', 'El manifiesto del snapshot está dañado.', array( 'status' => 500 ) );
	}

	private static function manifests() {
		$files = glob( self::dir() . '/*/manifest.json' );
		$out   = array();

		foreach ( $files ? $files : array() as $file ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$manifest = json_decode( (string) file_get_contents( $file ), true );
			if ( is_array( $manifest ) && ! empty( $manifest['snapshot_id'] ) ) {
				$out[] = $manifest;
			}
		}

		usort(
			$out,
			function ( $a, $b ) {
				return $b['created'] <=> $a['created'];
			}
		);

		return $out;
	}

	/**
	 * Vista pública: sin cursor ni verificador de clave.
	 */
	public static function view( array $m ) {
		$view = array(
			'snapshot_id'     => $m['snapshot_id'],
			'status'          => $m['status'],
			'label'           => isset( $m['label'] ) ? $m['label'] : '',
			'created'         => (int) $m['created'],
			'completed'       => isset( $m['completed'] ) ? (int) $m['completed'] : null,
			'expires'         => (int) $m['created'] + self::retention_hours() * HOUR_IN_SECONDS,
			'tables'          => count( $m['tables'] ),
			'excluded'        => isset( $m['excluded'] ) ? $m['excluded'] : array(),
			'rows'            => (int) $m['rows'],
			'size'            => (int) $m['size'],
			'estimated_bytes' => (int) $m['estimated_bytes'],
			'done'            => 'complete' === $m['status'],
			'progress'        => 'complete' === $m['status'] ? 100 : (int) floor( 100 * $m['cursor']['table'] / max( 1, count( $m['tables'] ) ) ),
		);

		if ( isset( $m['error'] ) ) {
			$view['error'] = $m['error'];
		}
		if ( isset( $m['restore'] ) ) {
			$view['restore'] = array_intersect_key( $m['restore'], array_flip( array( 'phase', 'started', 'finished', 'error', 'extra_tables' ) ) );
		}

		return $view;
	}

	public static function all() {
		return array_map( array( __CLASS__, 'view' ), self::manifests() );
	}

	public static function delete( $id ) {
		$manifest = self::get( $id );
		if ( is_wp_error( $manifest ) ) {
			return $manifest;
		}

		OneBit_WPM_Backups::rrmdir( self::dir() . '/' . $id );

		return true;
	}

	/**
	 * Borra los vencidos, los que exceden la cantidad a conservar y los abandonados.
	 */
	public static function prune() {
		$ttl      = self::retention_hours() * HOUR_IN_SECONDS;
		$keep     = self::keep();
		$now      = time();
		$complete = 0;
		$deleted  = 0;

		foreach ( self::manifests() as $m ) {
			$age = $now - (int) $m['created'];

			if ( 'complete' === $m['status'] ) {
				$complete++;
				$expired = $age > $ttl || $complete > $keep;
			} else {
				$expired = $age > self::ABANDONED_SECONDS;
			}

			if ( $expired ) {
				OneBit_WPM_Backups::rrmdir( self::dir() . '/' . $m['snapshot_id'] );
				$deleted++;
			}
		}

		return $deleted;
	}

	private static function key_for( array $manifest, $token ) {
		$key = OneBit_WPM_Crypto::key( $token, $manifest['snapshot_id'] );

		if ( ! hash_equals( (string) $manifest['key_check'], OneBit_WPM_Crypto::key_check( $key ) ) ) {
			return new WP_Error(
				'onebit_wpm_db_key',
				'El snapshot fue cifrado con otro token. Si regeneraste el token, los snapshots anteriores ya no se pueden abrir.',
				array( 'status' => 409 )
			);
		}

		return $key;
	}

	// ------------------------------------------------------------------ exportación

	/**
	 * @return array|WP_Error Manifiesto del snapshot nuevo.
	 */
	public static function start( $token, $label = '', $exclude = array() ) {
		global $wpdb;

		$reason = self::unavailable_reason();
		if ( $reason ) {
			return new WP_Error( 'onebit_wpm_db_unavailable', 'Snapshots de base no disponibles: ' . $reason . '.', array( 'status' => 409 ) );
		}

		self::prune();

		$tables   = self::tables();
		$excluded = array();

		foreach ( (array) $exclude as $suffix ) {
			$name = $wpdb->prefix . preg_replace( '/[^A-Za-z0-9_]/', '', (string) $suffix );
			if ( isset( $tables[ $name ] ) ) {
				unset( $tables[ $name ] );
				$excluded[] = $name;
			}
		}

		$bytes = array_sum( wp_list_pluck( $tables, 'bytes' ) );
		$dir   = self::dir();

		if ( function_exists( 'disk_free_space' ) ) {
			$free = @disk_free_space( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( false !== $free && $free < $bytes ) {
				return new WP_Error(
					'onebit_wpm_db_disk',
					sprintf( 'No hay espacio en disco para el snapshot: la base ocupa %s y quedan %s libres.', size_format( $bytes ), size_format( $free ) ),
					array( 'status' => 507 )
				);
			}
		}

		$id  = gmdate( 'Ymd-His' ) . '-' . strtolower( wp_generate_password( 8, false, false ) );
		$key = OneBit_WPM_Crypto::key( $token, $id );

		if ( ! wp_mkdir_p( $dir . '/' . $id ) ) {
			return new WP_Error( 'onebit_wpm_db_dir', 'No se pudo crear la carpeta del snapshot.', array( 'status' => 500 ) );
		}

		$manifest = array(
			'snapshot_id'     => $id,
			'status'          => 'in_progress',
			'label'           => sanitize_text_field( (string) $label ),
			'created'         => time(),
			'prefix'          => $wpdb->prefix,
			'tables'          => array_keys( $tables ),
			'excluded'        => $excluded,
			'estimated_bytes' => $bytes,
			'compression'     => function_exists( 'gzdeflate' ) ? 'deflate' : 'none',
			'key_check'       => OneBit_WPM_Crypto::key_check( $key ),
			'cursor'          => array(
				'table' => 0,
				'stage' => 'create',
			),
			'rows'            => 0,
			'size'            => 0,
		);

		self::save( $manifest );

		return $manifest;
	}

	/**
	 * Candado por snapshot: si el orquestador reintenta mientras el servidor sigue
	 * con el paso anterior, dos procesos no pueden escribir el mismo archivo.
	 *
	 * @return resource|WP_Error
	 */
	private static function lock( $id ) {
		if ( ! is_string( $id ) || ! preg_match( self::ID_PATTERN, $id ) ) {
			return new WP_Error( 'onebit_wpm_db_bad_id', 'Identificador de snapshot inválido.', array( 'status' => 400 ) );
		}
		if ( ! is_dir( self::dir() . '/' . $id ) ) {
			return new WP_Error( 'onebit_wpm_db_not_found', sprintf( 'No existe el snapshot %s (puede haber vencido).', $id ), array( 'status' => 404 ) );
		}

		$fh = fopen( self::dir() . '/' . $id . '/.lock', 'c' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( ! $fh || ! flock( $fh, LOCK_EX | LOCK_NB ) ) {
			if ( $fh ) {
				fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			}
			return new WP_Error( 'onebit_wpm_db_busy', 'Hay otro paso de este snapshot en curso.', array( 'status' => 409 ) );
		}

		return $fh;
	}

	private static function unlock( $fh ) {
		flock( $fh, LOCK_UN );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
	}

	/**
	 * Avanza la exportación durante el tiempo disponible de esta petición.
	 *
	 * @return array|WP_Error Vista pública con 'done'.
	 */
	public static function step( $id, $token ) {
		$lock = self::lock( $id );
		if ( is_wp_error( $lock ) ) {
			return $lock;
		}

		try {
			return self::run_step( $id, $token );
		} finally {
			self::unlock( $lock );
		}
	}

	/**
	 * Avanza la restauración durante el tiempo disponible de esta petición.
	 *
	 * @return array|WP_Error
	 */
	public static function restore_step( $id, $token ) {
		$lock = self::lock( $id );
		if ( is_wp_error( $lock ) ) {
			return $lock;
		}

		try {
			return self::run_restore_step( $id, $token );
		} finally {
			self::unlock( $lock );
		}
	}

	private static function run_step( $id, $token ) {
		global $wpdb;

		$manifest = self::get( $id );
		if ( is_wp_error( $manifest ) ) {
			return $manifest;
		}
		if ( 'complete' === $manifest['status'] ) {
			return self::view( $manifest );
		}
		if ( 'in_progress' !== $manifest['status'] ) {
			return new WP_Error( 'onebit_wpm_db_state', 'El snapshot falló y no se puede continuar: tomá uno nuevo.', array( 'status' => 409 ) );
		}

		$key = self::key_for( $manifest, $token );
		if ( is_wp_error( $key ) ) {
			return $key;
		}

		self::extend_time();

		$deadline = microtime( true ) + self::budget();
		$tables   = $manifest['tables'];
		$cursor   = $manifest['cursor'];
		$fh       = fopen( self::data_path( $id ), 'ab' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( ! $fh ) {
			return new WP_Error( 'onebit_wpm_db_open', 'No se pudo escribir el archivo del snapshot.', array( 'status' => 500 ) );
		}

		try {
			while ( microtime( true ) < $deadline && $cursor['table'] < count( $tables ) ) {
				$table = $tables[ $cursor['table'] ];

				if ( 'create' === $cursor['stage'] ) {
					$row = $wpdb->get_row( 'SHOW CREATE TABLE ' . self::quote( $table ), ARRAY_N );

					if ( ! $row ) {
						// La tabla desapareció desde que empezó el snapshot.
						$cursor = array( 'table' => $cursor['table'] + 1, 'stage' => 'create' );
						continue;
					}

					self::write(
						$fh,
						$key,
						$manifest,
						array(
							't'     => 'create',
							'table' => $table,
							'sql'   => $row[1],
						)
					);

					$cursor = array_merge(
						array(
							'table'  => $cursor['table'],
							'stage'  => 'rows',
							'after'  => null,
							'offset' => 0,
						),
						self::pagination( $table )
					);
					continue;
				}

				$batch = self::fetch( $table, $cursor );

				if ( $batch ) {
					self::write_rows( $fh, $key, $manifest, $table, $batch );
					$manifest['rows'] += count( $batch );

					if ( $cursor['keyset'] ) {
						$last            = end( $batch );
						$cursor['after'] = $last[ $cursor['keyset'] ];
					} else {
						$cursor['offset'] += count( $batch );
					}
				}

				if ( count( $batch ) < self::BATCH_ROWS ) {
					$cursor = array( 'table' => $cursor['table'] + 1, 'stage' => 'create' );
				}

				// Con SAVEQUERIES activo, el registro de consultas crecería sin límite.
				$wpdb->queries = array();
			}

			if ( $cursor['table'] >= count( $tables ) ) {
				self::write( $fh, $key, $manifest, array( 't' => 'end' ) );
				$manifest['status']    = 'complete';
				$manifest['completed'] = time();
			}
		} catch ( Exception $e ) {
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			@unlink( self::data_path( $id ) );

			$manifest['status'] = 'failed';
			$manifest['error']  = $e->getMessage();
			self::save( $manifest );

			OneBit_WPM_Log::add( 'error', 'Falló el snapshot de la base: ' . $e->getMessage() );

			return new WP_Error( 'onebit_wpm_db_snapshot_failed', 'Falló el snapshot de la base: ' . $e->getMessage(), array( 'status' => 500 ) );
		}

		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		clearstatcache();

		$manifest['cursor'] = $cursor;
		$manifest['size']   = (int) filesize( self::data_path( $id ) );
		self::save( $manifest );

		if ( 'complete' === $manifest['status'] ) {
			OneBit_WPM_Log::add(
				'info',
				sprintf( 'Snapshot de base %s: %d tablas, %s cifrados%s.', $id, count( $tables ), size_format( $manifest['size'] ), $manifest['label'] ? ' (' . $manifest['label'] . ')' : '' )
			);
			self::prune();
		}

		return self::view( $manifest );
	}

	private static function fetch( $table, array $cursor ) {
		global $wpdb;

		$sql = 'SELECT * FROM ' . self::quote( $table );

		if ( $cursor['keyset'] ) {
			$pk = self::quote( $cursor['keyset'] );
			if ( null !== $cursor['after'] ) {
				$sql .= " WHERE $pk > '" . self::escape( (string) $cursor['after'] ) . "'";
			}
			$sql .= " ORDER BY $pk ASC LIMIT " . self::BATCH_ROWS;
		} else {
			if ( $cursor['order'] ) {
				$sql .= ' ORDER BY ' . implode( ', ', array_map( array( __CLASS__, 'quote' ), $cursor['order'] ) );
			}
			$sql .= ' LIMIT ' . (int) $cursor['offset'] . ', ' . self::BATCH_ROWS;
		}

		$rows = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		if ( $wpdb->last_error ) {
			throw new RuntimeException( sprintf( 'error leyendo %s: %s', $table, $wpdb->last_error ) );
		}

		return $rows ? $rows : array();
	}

	/**
	 * Parte un lote de filas en bloques de tamaño acotado.
	 */
	private static function write_rows( $fh, $key, array $manifest, $table, array $batch ) {
		$columns = array_keys( $batch[0] );
		$rows    = array();
		$bytes   = 0;

		foreach ( $batch as $row ) {
			$values = array();
			foreach ( $row as $value ) {
				if ( null === $value ) {
					$values[] = null;
				} elseif ( preg_match( '//u', $value ) ) {
					$values[] = $value;
					$bytes   += strlen( $value );
				} else {
					// Binario: JSON solo admite UTF-8 válido.
					$values[] = array( 'b' => base64_encode( $value ) );
					$bytes   += strlen( $value ) * 2;
				}
			}
			$rows[] = $values;

			if ( $bytes >= self::CHUNK_BYTES ) {
				self::write( $fh, $key, $manifest, array( 't' => 'rows', 'table' => $table, 'columns' => $columns, 'rows' => $rows ) );
				$rows  = array();
				$bytes = 0;
			}
		}

		if ( $rows ) {
			self::write( $fh, $key, $manifest, array( 't' => 'rows', 'table' => $table, 'columns' => $columns, 'rows' => $rows ) );
		}
	}

	private static function write( $fh, $key, array $manifest, array $record ) {
		$json = wp_json_encode( $record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

		if ( false === $json ) {
			throw new RuntimeException( 'no se pudo serializar un bloque de ' . ( isset( $record['table'] ) ? $record['table'] : 'datos' ) );
		}

		$plain  = 'deflate' === $manifest['compression'] ? gzdeflate( $json, 6 ) : $json;
		$sealed = OneBit_WPM_Crypto::seal( $plain, $key );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		if ( false === $sealed || strlen( $sealed ) !== fwrite( $fh, $sealed ) ) {
			throw new RuntimeException( 'no se pudo escribir en disco (¿espacio agotado?)' );
		}
	}

	// ------------------------------------------------------------------ restauración

	private static function run_restore_step( $id, $token ) {

		$manifest = self::get( $id );
		if ( is_wp_error( $manifest ) ) {
			return $manifest;
		}
		if ( 'complete' !== $manifest['status'] ) {
			return new WP_Error( 'onebit_wpm_db_incomplete', 'El snapshot no está completo y no se puede restaurar.', array( 'status' => 409 ) );
		}

		$key = self::key_for( $manifest, $token );
		if ( is_wp_error( $key ) ) {
			return $key;
		}

		self::extend_time();

		$state = isset( $manifest['restore'] ) && 'loading' === $manifest['restore']['phase'] ? $manifest['restore'] : null;

		if ( ! $state ) {
			self::drop_work_tables();
			$state = array(
				'phase'   => 'loading',
				'offset'  => 0,
				'started' => time(),
				'tables'  => array(),
				'fks'     => array(),
			);
		}

		$deadline = microtime( true ) + self::budget();
		$fh       = fopen( self::data_path( $id ), 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( ! $fh ) {
			return new WP_Error( 'onebit_wpm_db_open', 'No se pudo abrir el archivo del snapshot.', array( 'status' => 500 ) );
		}

		try {
			self::exec( 'SET foreign_key_checks = 0' );
			fseek( $fh, $state['offset'] );

			while ( 'loading' === $state['phase'] && microtime( true ) < $deadline ) {
				$record = self::read( $fh, $key, $manifest );

				if ( null === $record ) {
					throw new RuntimeException( 'el archivo termina antes del final: está incompleto o dañado' );
				}

				if ( 'create' === $record['t'] ) {
					$tmp = self::temp_name( $id, $record['table'] );
					list( $sql, $fks ) = self::prepare_create( $record['sql'], $record['table'], $tmp );

					self::exec( 'DROP TABLE IF EXISTS ' . self::quote( $tmp ) );
					self::exec( $sql );

					$state['tables'][] = $record['table'];
					if ( $fks ) {
						$state['fks'][ $record['table'] ] = $fks;
					}
				} elseif ( 'rows' === $record['t'] ) {
					self::insert_rows( self::temp_name( $id, $record['table'] ), $record );
				} elseif ( 'end' === $record['t'] ) {
					$state['phase'] = 'swap';
				}

				$state['offset'] = ftell( $fh );
			}

			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			$fh = null;

			if ( 'swap' === $state['phase'] ) {
				$state['extra_tables'] = self::swap( $id, $state['tables'], $state['fks'], $manifest['excluded'] );
				$state['phase']        = 'done';
				$state['finished']     = time();
				unset( $state['fks'] );
			}
		} catch ( Exception $e ) {
			if ( $fh ) {
				fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			}
			self::drop_work_tables();

			$manifest['restore'] = array(
				'phase' => 'failed',
				'error' => $e->getMessage(),
				'time'  => time(),
			);
			self::save( $manifest );

			OneBit_WPM_Log::add( 'error', sprintf( 'Falló la restauración de la base desde %s: %s. La base en uso no se modificó.', $id, $e->getMessage() ) );

			return new WP_Error(
				'onebit_wpm_db_restore_failed',
				'Falló la restauración: ' . $e->getMessage() . '. La base en uso no se modificó.',
				array( 'status' => 500 )
			);
		}

		$manifest['restore'] = $state;
		self::save( $manifest );

		if ( 'done' === $state['phase'] ) {
			OneBit_WPM_Log::add(
				'warning',
				sprintf(
					'Base restaurada desde el snapshot %s, tomado el %s%s.',
					$id,
					wp_date( 'Y-m-d H:i', $manifest['created'] ),
					defined( 'ONEBIT_WPM_RESCUE' ) ? ' (modo rescate)' : ''
				)
			);
		}

		return array(
			'snapshot_id'      => $id,
			'snapshot_created' => (int) $manifest['created'],
			'phase'            => $state['phase'],
			'done'             => 'done' === $state['phase'],
			'progress'         => (int) floor( 100 * $state['offset'] / max( 1, $manifest['size'] ) ),
			'tables_loaded'    => count( $state['tables'] ),
			'tables_total'     => count( $manifest['tables'] ),
			'extra_tables'     => isset( $state['extra_tables'] ) ? $state['extra_tables'] : array(),
			'rescue_mode'      => defined( 'ONEBIT_WPM_RESCUE' ),
		);
	}

	private static function read( $fh, $key, array $manifest ) {
		$head = fread( $fh, 4 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread

		if ( false === $head || '' === $head ) {
			return null;
		}
		if ( 4 !== strlen( $head ) ) {
			throw new RuntimeException( 'bloque truncado' );
		}

		$len = unpack( 'N', $head )[1];
		if ( $len < OneBit_WPM_Crypto::IV_LEN + OneBit_WPM_Crypto::TAG_LEN || $len > 64 * MB_IN_BYTES ) {
			throw new RuntimeException( 'bloque con longitud inválida' );
		}

		$payload = '';
		while ( strlen( $payload ) < $len && ! feof( $fh ) ) {
			$chunk = fread( $fh, $len - strlen( $payload ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread
			if ( false === $chunk || '' === $chunk ) {
				break;
			}
			$payload .= $chunk;
		}

		if ( strlen( $payload ) !== $len ) {
			throw new RuntimeException( 'bloque truncado' );
		}

		$plain = OneBit_WPM_Crypto::open( $payload, $key );
		if ( false === $plain ) {
			throw new RuntimeException( 'un bloque no pasó la verificación de integridad (archivo alterado o dañado)' );
		}

		if ( 'deflate' === $manifest['compression'] ) {
			$plain = gzinflate( $plain );
			if ( false === $plain ) {
				throw new RuntimeException( 'no se pudo descomprimir un bloque' );
			}
		}

		$record = json_decode( $plain, true );
		if ( ! is_array( $record ) || empty( $record['t'] ) ) {
			throw new RuntimeException( 'bloque ilegible' );
		}

		return $record;
	}

	/**
	 * Renombra la tabla a la temporal y separa las claves foráneas: sus nombres son
	 * únicos en toda la base y chocarían con los de la tabla en uso. Se agregan
	 * después del intercambio, cuando las tablas viejas ya no existen.
	 */
	private static function prepare_create( $sql, $table, $tmp ) {
		$needle = 'CREATE TABLE ' . self::quote( $table );

		if ( 0 !== strpos( $sql, $needle ) ) {
			throw new RuntimeException( 'definición inesperada de la tabla ' . $table );
		}

		$sql = 'CREATE TABLE ' . self::quote( $tmp ) . substr( $sql, strlen( $needle ) );
		$fks = array();

		$sql = preg_replace_callback(
			'/,\s*\n\s*(CONSTRAINT\s+`(?:[^`]|``)+`\s+FOREIGN KEY[^\n]*?)(?=\s*\n)/',
			function ( $m ) use ( &$fks ) {
				$fks[] = trim( $m[1] );
				return '';
			},
			$sql
		);

		return array( $sql, $fks );
	}

	private static function insert_rows( $tmp, array $record ) {
		$columns = implode( ', ', array_map( array( __CLASS__, 'quote' ), $record['columns'] ) );
		$tuples  = array();

		foreach ( $record['rows'] as $row ) {
			$values = array();
			foreach ( $row as $value ) {
				if ( null === $value ) {
					$values[] = 'NULL';
				} elseif ( is_array( $value ) ) {
					$raw      = base64_decode( $value['b'] ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
					$values[] = '' === $raw ? "''" : '0x' . bin2hex( $raw );
				} else {
					$values[] = "'" . self::escape( $value ) . "'";
				}
			}
			$tuples[] = '(' . implode( ', ', $values ) . ')';
		}

		if ( $tuples ) {
			self::exec( 'INSERT INTO ' . self::quote( $tmp ) . " ($columns) VALUES " . implode( ', ', $tuples ) );
		}
	}

	/**
	 * Intercambio atómico de tablas y reposición del estado del plugin.
	 *
	 * @return string[] Tablas que existen ahora pero no estaban en el snapshot (se dejan como están).
	 */
	private static function swap( $id, array $tables, array $fks, array $excluded ) {
		global $wpdb;

		$preserved = self::capture_state();
		$existing  = array_keys( self::tables() );
		$present   = array_flip( $existing );

		$pairs = array();
		$old   = array();

		foreach ( $tables as $table ) {
			if ( isset( $present[ $table ] ) ) {
				$old[]   = self::old_name( $id, $table );
				$pairs[] = self::quote( $table ) . ' TO ' . self::quote( self::old_name( $id, $table ) );
			}
			$pairs[] = self::quote( self::temp_name( $id, $table ) ) . ' TO ' . self::quote( $table );
		}

		self::exec( 'SET foreign_key_checks = 0' );
		self::exec( 'RENAME TABLE ' . implode( ', ', $pairs ) );

		// A partir de acá los datos ya están restaurados: lo que falle es un aviso, no una vuelta atrás.
		foreach ( $old as $name ) {
			try {
				self::exec( 'DROP TABLE IF EXISTS ' . self::quote( $name ) );
			} catch ( Exception $e ) {
				OneBit_WPM_Log::add( 'warning', sprintf( 'No se pudo borrar la tabla auxiliar %s: %s', $name, $e->getMessage() ) );
			}
		}

		foreach ( $fks as $table => $clauses ) {
			foreach ( $clauses as $clause ) {
				try {
					self::exec( 'ALTER TABLE ' . self::quote( $table ) . ' ADD ' . $clause );
				} catch ( Exception $e ) {
					OneBit_WPM_Log::add( 'warning', sprintf( 'No se pudo recrear una clave foránea de %s: %s', $table, $e->getMessage() ) );
				}
			}
		}

		self::restore_state( $preserved );
		wp_cache_flush();

		return array_values( array_diff( $existing, $tables, $excluded ) );
	}

	private static function capture_state() {
		global $wpdb;

		$options = array();
		foreach ( self::PRESERVED_OPTIONS as $name ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT option_value, autoload FROM {$wpdb->options} WHERE option_name = %s", $name ), ARRAY_A );
			if ( $row ) {
				$options[ $name ] = $row;
			}
		}

		$user_id = get_current_user_id();
		$app     = $user_id
			? $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key = '_application_passwords'", $user_id ) )
			: null;

		return array(
			'options' => $options,
			'user_id' => $user_id,
			'app'     => $app,
		);
	}

	private static function restore_state( array $state ) {
		global $wpdb;

		foreach ( $state['options'] as $name => $row ) {
			$wpdb->delete( $wpdb->options, array( 'option_name' => $name ) );
			$wpdb->insert(
				$wpdb->options,
				array(
					'option_name'  => $name,
					'option_value' => $row['option_value'],
					'autoload'     => $row['autoload'],
				)
			);
		}

		$wpdb->delete( $wpdb->options, array( 'option_name' => OneBit_WPM_Updater::LOCK_OPTION ) );

		// Las contraseñas de aplicación del usuario que restaura: sin ellas, el
		// orquestador quedaría afuera si la creó después del snapshot.
		if ( $state['user_id'] && null !== $state['app'] ) {
			$wpdb->delete( $wpdb->usermeta, array( 'user_id' => $state['user_id'], 'meta_key' => '_application_passwords' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
			$wpdb->insert( $wpdb->usermeta, array( 'user_id' => $state['user_id'], 'meta_key' => '_application_passwords', 'meta_value' => $state['app'] ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		}

		// El plugin tiene que seguir activo aunque el snapshot diga otra cosa.
		$self   = plugin_basename( ONEBIT_WPM_FILE );
		$active = maybe_unserialize( $wpdb->get_var( "SELECT option_value FROM {$wpdb->options} WHERE option_name = 'active_plugins'" ) );
		if ( is_array( $active ) && ! in_array( $self, $active, true ) ) {
			$active[] = $self;
			$wpdb->update( $wpdb->options, array( 'option_value' => serialize( $active ) ), array( 'option_name' => 'active_plugins' ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
		}
	}

	/**
	 * Borra tablas temporales de restauraciones interrumpidas.
	 */
	public static function drop_work_tables() {
		global $wpdb;

		foreach ( array( self::TEMP_TAG, self::OLD_TAG ) as $tag ) {
			$names = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->prefix . $tag ) . '%' ) );
			foreach ( (array) $names as $name ) {
				self::exec( 'DROP TABLE IF EXISTS ' . self::quote( $name ) );
			}
		}
	}

	private static function extend_time() {
		if ( function_exists( 'ignore_user_abort' ) ) {
			ignore_user_abort( true );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore
		}
	}
}
