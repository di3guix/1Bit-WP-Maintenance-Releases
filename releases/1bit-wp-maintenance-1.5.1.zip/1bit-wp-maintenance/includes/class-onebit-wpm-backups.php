<?php
/**
 * Backups de archivos por plugin/tema y su restauración.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Backups {

	const DIR_OPTION   = 'onebit_wpm_backup_dir';
	const DIR_PATTERN  = '/^1bit-wpm-[a-z0-9]{16}$/';
	const ID_PATTERN   = '/^\d{8}-\d{6}-[a-z0-9]{8}$/';
	const PLUGIN_ARCHIVE = 'files.zip';

	/**
	 * Carpeta base de backups dentro de uploads. El nombre es aleatorio: en
	 * servidores sin .htaccess (nginx) es la principal barrera contra descargas.
	 */
	public static function base_dir() {
		$name = get_option( self::DIR_OPTION );

		if ( ! is_string( $name ) || ! preg_match( self::DIR_PATTERN, $name ) ) {
			$name = '1bit-wpm-' . strtolower( wp_generate_password( 16, false, false ) );
			update_option( self::DIR_OPTION, $name, false );
		}

		$uploads = wp_upload_dir( null, false );
		$dir     = trailingslashit( $uploads['basedir'] ) . $name;

		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		self::protect( $dir );

		return $dir;
	}

	public static function protect( $dir ) {
		$files = array(
			'.htaccess' => "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n",
			'index.php' => "<?php\n// Silence is golden.\n",
		);

		foreach ( $files as $name => $content ) {
			if ( ! file_exists( $dir . '/' . $name ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				@file_put_contents( $dir . '/' . $name, $content );
			}
		}
	}

	/**
	 * Datos de ubicación y versión de un plugin (plugin-file) o tema (stylesheet).
	 *
	 * @return array|WP_Error
	 */
	public static function describe( $type, $item ) {
		if ( 'plugin' === $type ) {
			$file = WP_PLUGIN_DIR . '/' . $item;

			if ( validate_file( $item ) || ! file_exists( $file ) ) {
				return new WP_Error( 'onebit_wpm_unknown_item', sprintf( 'El plugin %s no está instalado.', $item ), array( 'status' => 404 ) );
			}

			$single = ( '.' === dirname( $item ) );

			return array(
				'slug'        => $single ? $item : dirname( $item ),
				'source'      => $single ? $file : WP_PLUGIN_DIR . '/' . dirname( $item ),
				'version'     => self::current_version( $type, $item ),
				'single_file' => $single,
			);
		}

		$theme = wp_get_theme( $item );

		if ( validate_file( $item ) || ! $theme->exists() ) {
			return new WP_Error( 'onebit_wpm_unknown_item', sprintf( 'El tema %s no está instalado.', $item ), array( 'status' => 404 ) );
		}

		return array(
			'slug'        => $item,
			'source'      => $theme->get_stylesheet_directory(),
			'version'     => self::current_version( $type, $item ),
			'single_file' => false,
		);
	}

	/**
	 * Versión leída directo del disco, sin cachés: tras actualizar en el mismo
	 * request, get_plugins() y WP_Theme devuelven datos viejos.
	 */
	public static function current_version( $type, $item ) {
		if ( 'plugin' === $type ) {
			$file = WP_PLUGIN_DIR . '/' . $item;
		} else {
			$file = get_theme_root( $item ) . '/' . $item . '/style.css';
		}

		if ( ! file_exists( $file ) ) {
			return null;
		}

		$data = get_file_data( $file, array( 'Version' => 'Version' ) );

		return $data['Version'];
	}

	/**
	 * @return array|WP_Error Manifiesto del backup.
	 */
	public static function create( $type, $item ) {
		$info = self::describe( $type, $item );
		if ( is_wp_error( $info ) ) {
			return $info;
		}

		$backup_id = gmdate( 'Ymd-His' ) . '-' . strtolower( wp_generate_password( 8, false, false ) );
		$dir       = self::base_dir() . '/' . $backup_id;

		if ( ! wp_mkdir_p( $dir ) ) {
			return new WP_Error( 'onebit_wpm_backup_dir', 'No se pudo crear la carpeta del backup.', array( 'status' => 500 ) );
		}

		if ( $info['single_file'] ) {
			$archive = 'plugin-file.bak';
			if ( ! copy( $info['source'], $dir . '/' . $archive ) ) {
				self::rrmdir( $dir );
				return new WP_Error( 'onebit_wpm_backup_copy', 'No se pudo copiar el plugin al backup.', array( 'status' => 500 ) );
			}
		} else {
			$archive = self::PLUGIN_ARCHIVE;
			$zipped  = self::zip_dir( $info['source'], $dir . '/' . $archive );
			if ( is_wp_error( $zipped ) ) {
				self::rrmdir( $dir );
				return $zipped;
			}
		}

		$size = (int) filesize( $dir . '/' . $archive );
		if ( $size <= 0 ) {
			self::rrmdir( $dir );
			return new WP_Error( 'onebit_wpm_backup_empty', 'El backup quedó vacío.', array( 'status' => 500 ) );
		}

		$manifest = array(
			'backup_id'      => $backup_id,
			'created'        => time(),
			'created_iso'    => gmdate( 'c' ),
			'type'           => $type,
			'item'           => $item,
			'slug'           => $info['slug'],
			'version_before' => $info['version'],
			'archive'        => $archive,
			'single_file'    => $info['single_file'],
			'size'           => $size,
		);

		self::write_manifest( $backup_id, $manifest );

		return $manifest;
	}

	/**
	 * Comprime un directorio con ZipArchive o, si no está, con PclZip (incluido en WordPress).
	 */
	private static function zip_dir( $source, $destination ) {
		if ( ! is_dir( $source ) ) {
			return new WP_Error( 'onebit_wpm_backup_source', 'No existe la carpeta a respaldar.', array( 'status' => 500 ) );
		}

		$source = untrailingslashit( wp_normalize_path( realpath( $source ) ) );
		$parent = dirname( $source );

		if ( class_exists( 'ZipArchive' ) ) {
			$zip = new ZipArchive();

			if ( true !== $zip->open( $destination, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
				return new WP_Error( 'onebit_wpm_zip_open', 'No se pudo crear el zip del backup.', array( 'status' => 500 ) );
			}

			$zip->addEmptyDir( basename( $source ) );

			$files = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $source, RecursiveDirectoryIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::SELF_FIRST
			);

			foreach ( $files as $file ) {
				$path     = wp_normalize_path( $file->getPathname() );
				$relative = ltrim( substr( $path, strlen( $parent ) ), '/' );

				if ( $file->isDir() ) {
					$zip->addEmptyDir( $relative );
				} else {
					$zip->addFile( $path, $relative );
				}
			}

			if ( ! $zip->close() ) {
				return new WP_Error( 'onebit_wpm_zip_close', 'Falló la escritura del zip del backup.', array( 'status' => 500 ) );
			}

			return true;
		}

		require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';

		$zip    = new PclZip( $destination );
		$result = $zip->create( $source, PCLZIP_OPT_REMOVE_PATH, $parent );

		if ( 0 === $result ) {
			return new WP_Error( 'onebit_wpm_pclzip', 'PclZip no pudo crear el backup: ' . $zip->errorInfo( true ), array( 'status' => 500 ) );
		}

		return true;
	}

	/**
	 * Restaura un backup. Aparta la versión actual antes de descomprimir y la
	 * repone si la restauración falla, para no dejar el item a medio instalar.
	 *
	 * @return array|WP_Error
	 */
	public static function restore( $backup_id ) {
		$manifest = self::get( $backup_id );
		if ( is_wp_error( $manifest ) ) {
			return $manifest;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';

		if ( ! WP_Filesystem() ) {
			return new WP_Error( 'onebit_wpm_filesystem', 'No se pudo inicializar el sistema de archivos de WordPress.', array( 'status' => 500 ) );
		}

		global $wp_filesystem;

		$archive = self::dir_for( $backup_id ) . '/' . $manifest['archive'];
		if ( ! file_exists( $archive ) ) {
			return new WP_Error( 'onebit_wpm_archive_missing', 'Falta el archivo del backup.', array( 'status' => 500 ) );
		}

		$root    = ( 'plugin' === $manifest['type'] ) ? WP_PLUGIN_DIR : get_theme_root( $manifest['slug'] );
		$current = $root . '/' . $manifest['slug'];

		if ( ! empty( $manifest['single_file'] ) ) {
			if ( ! copy( $archive, $current ) ) {
				return new WP_Error( 'onebit_wpm_restore_copy', 'No se pudo restaurar el archivo del plugin.', array( 'status' => 500 ) );
			}
			self::invalidate_opcache( $current );
		} else {
			$aside = $current . '.onebit-wpm-' . strtolower( wp_generate_password( 6, false, false ) );
			$moved = false;

			if ( file_exists( $current ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
				if ( ! @rename( $current, $aside ) ) {
					return new WP_Error( 'onebit_wpm_restore_move', 'No se pudo apartar la versión actual para restaurar.', array( 'status' => 500 ) );
				}
				$moved = true;
			}

			$unzipped = unzip_file( $archive, $root );

			if ( is_wp_error( $unzipped ) || ! is_dir( $current ) ) {
				if ( is_dir( $current ) ) {
					$wp_filesystem->delete( $current, true );
				}
				if ( $moved ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
					@rename( $aside, $current );
				}

				$message = is_wp_error( $unzipped ) ? $unzipped->get_error_message() : 'el zip no contenía la carpeta esperada';
				return new WP_Error( 'onebit_wpm_restore_unzip', 'Falló la restauración: ' . $message, array( 'status' => 500 ) );
			}

			if ( $moved ) {
				$wp_filesystem->delete( $aside, true );
			}

			self::invalidate_opcache( $current );
		}

		if ( 'plugin' === $manifest['type'] ) {
			wp_clean_plugins_cache( true );
		} else {
			wp_clean_themes_cache( true );
		}

		$manifest['restored_at'] = time();
		self::write_manifest( $backup_id, $manifest );

		return array(
			'backup_id'        => $backup_id,
			'type'             => $manifest['type'],
			'item'             => $manifest['item'],
			'version_restored' => $manifest['version_before'],
			'version_now'      => self::current_version( $manifest['type'], $manifest['item'] ),
		);
	}

	private static function invalidate_opcache( $path ) {
		if ( is_dir( $path ) && function_exists( 'wp_opcache_invalidate_directory' ) ) {
			wp_opcache_invalidate_directory( $path );
		} elseif ( is_file( $path ) && function_exists( 'wp_opcache_invalidate' ) ) {
			wp_opcache_invalidate( $path, true );
		}
	}

	public static function all() {
		$files = glob( self::base_dir() . '/*/manifest.json' );
		$out   = array();

		foreach ( $files ? $files : array() as $file ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$manifest = json_decode( (string) file_get_contents( $file ), true );
			if ( is_array( $manifest ) && ! empty( $manifest['backup_id'] ) ) {
				$out[] = $manifest;
			}
		}

		usort(
			$out,
			function ( $a, $b ) {
				return $b['created'] <=> $a['created'];
			}
		);

		return $out;
	}

	/**
	 * @return array|WP_Error
	 */
	public static function get( $backup_id ) {
		if ( ! is_string( $backup_id ) || ! preg_match( self::ID_PATTERN, $backup_id ) ) {
			return new WP_Error( 'onebit_wpm_bad_backup_id', 'Identificador de backup inválido.', array( 'status' => 400 ) );
		}

		$file = self::dir_for( $backup_id ) . '/manifest.json';
		if ( ! file_exists( $file ) ) {
			return new WP_Error( 'onebit_wpm_no_backup', sprintf( 'No existe el backup %s.', $backup_id ), array( 'status' => 404 ) );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$manifest = json_decode( (string) file_get_contents( $file ), true );
		if ( ! is_array( $manifest ) ) {
			return new WP_Error( 'onebit_wpm_bad_manifest', 'El manifiesto del backup está dañado.', array( 'status' => 500 ) );
		}

		return $manifest;
	}

	public static function delete( $backup_id ) {
		$manifest = self::get( $backup_id );
		if ( is_wp_error( $manifest ) ) {
			return $manifest;
		}

		self::rrmdir( self::dir_for( $backup_id ) );
		return true;
	}

	/**
	 * Borra backups más viejos que $days días. Devuelve cuántos eliminó.
	 */
	public static function prune( $days ) {
		$limit   = time() - ( (int) $days * DAY_IN_SECONDS );
		$deleted = 0;

		foreach ( self::all() as $manifest ) {
			if ( (int) $manifest['created'] < $limit && true === self::delete( $manifest['backup_id'] ) ) {
				$deleted++;
			}
		}

		return $deleted;
	}

	private static function dir_for( $backup_id ) {
		return self::base_dir() . '/' . $backup_id;
	}

	private static function write_manifest( $backup_id, $manifest ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		file_put_contents( self::dir_for( $backup_id ) . '/manifest.json', wp_json_encode( $manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
	}

	/**
	 * Borrado recursivo sin depender de WP_Filesystem (el cron no lo inicializa).
	 */
	public static function rrmdir( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		$items = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $items as $item ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions
			$item->isDir() ? @rmdir( $item->getPathname() ) : @unlink( $item->getPathname() );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions
		@rmdir( $dir );
	}
}
