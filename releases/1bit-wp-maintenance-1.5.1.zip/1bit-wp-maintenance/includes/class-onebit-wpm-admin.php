<?php
/**
 * Pantalla Herramientas > 1Bit Maintenance.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Admin {

	const SLUG          = '1bit-wp-maintenance';
	const ACTION        = 'onebit_wpm_action';
	const LOOPBACK_OPTION = 'onebit_wpm_last_loopback';

	public static function boot() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( 'OneBit_WPM_Guard', 'ensure' ) );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( ONEBIT_WPM_FILE ), array( __CLASS__, 'action_links' ) );
	}

	public static function menu() {
		add_management_page( '1Bit Maintenance', '1Bit Maintenance', 'update_plugins', self::SLUG, array( __CLASS__, 'render' ) );
	}

	public static function action_links( $links ) {
		array_unshift( $links, sprintf( '<a href="%s">%s</a>', esc_url( self::url() ), esc_html__( 'Configurar', '1bit-wp-maintenance' ) ) );
		return $links;
	}

	private static function url() {
		return admin_url( 'tools.php?page=' . self::SLUG );
	}

	private static function flash( $type, $message ) {
		set_transient( 'onebit_wpm_flash_' . get_current_user_id(), array( 'type' => $type, 'message' => $message ), 300 );
	}

	public static function handle() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'No tenés permisos para esta acción.', '1bit-wp-maintenance' ), 403 );
		}

		check_admin_referer( self::ACTION );

		$do        = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$backup_id = isset( $_POST['backup_id'] ) ? sanitize_text_field( wp_unslash( $_POST['backup_id'] ) ) : '';

		switch ( $do ) {
			case 'generate_token':
				$token = OneBit_WPM_Token::generate();
				OneBit_WPM_Log::add( 'info', sprintf( 'Token regenerado por %s.', wp_get_current_user()->user_login ) );
				self::flash( 'token', $token );
				break;

			case 'loopback':
				$result = OneBit_WPM_Health::loopback( array( '/' ) );
				update_option( self::LOOPBACK_OPTION, array( 'time' => time(), 'result' => $result ), false );
				self::flash( $result['ok'] ? 'success' : 'error', $result['ok'] ? 'El loopback funciona.' : 'El loopback falló: ' . $result['summary'] );
				break;

			case 'restore':
				$result = OneBit_WPM_Updater::rollback( $backup_id );
				if ( is_wp_error( $result ) ) {
					self::flash( 'error', $result->get_error_message() );
				} else {
					self::flash( 'success', sprintf( 'Restaurado %s a la versión %s.', $result['item'], $result['version_restored'] ) );
				}
				break;

			case 'delete':
				$result = OneBit_WPM_Backups::delete( $backup_id );
				self::flash( is_wp_error( $result ) ? 'error' : 'success', is_wp_error( $result ) ? $result->get_error_message() : 'Backup eliminado.' );
				break;

			case 'settings':
				$days = isset( $_POST['retention_days'] ) ? absint( $_POST['retention_days'] ) : OneBit_WPM_Plugin::DEFAULT_RETENTION;
				update_option( OneBit_WPM_Plugin::RETENTION_OPTION, max( 1, min( 365, $days ) ), false );
				self::flash( 'success', 'Ajustes guardados.' );
				break;

			case 'db_delete':
				$snapshot_id = isset( $_POST['snapshot_id'] ) ? sanitize_text_field( wp_unslash( $_POST['snapshot_id'] ) ) : '';
				$result      = OneBit_WPM_Db_Snapshots::delete( $snapshot_id );
				self::flash( is_wp_error( $result ) ? 'error' : 'success', is_wp_error( $result ) ? $result->get_error_message() : 'Snapshot de base eliminado.' );
				break;

			case 'db_settings':
				$hours = isset( $_POST['db_retention_hours'] ) ? absint( $_POST['db_retention_hours'] ) : OneBit_WPM_Db_Snapshots::DEFAULT_RETENTION;
				$keep  = isset( $_POST['db_keep'] ) ? absint( $_POST['db_keep'] ) : OneBit_WPM_Db_Snapshots::DEFAULT_KEEP;
				update_option( OneBit_WPM_Db_Snapshots::RETENTION_OPTION, max( 1, min( OneBit_WPM_Db_Snapshots::MAX_RETENTION, $hours ) ), false );
				update_option( OneBit_WPM_Db_Snapshots::KEEP_OPTION, max( 1, min( OneBit_WPM_Db_Snapshots::MAX_KEEP, $keep ) ), false );
				OneBit_WPM_Db_Snapshots::prune();
				self::flash( 'success', 'Ajustes de snapshots guardados.' );
				break;

			case 'diagnose_app_passwords':
				set_transient( 'onebit_wpm_diagnosis_' . get_current_user_id(), OneBit_WPM_Diagnostics::scan(), 15 * MINUTE_IN_SECONDS );
				self::flash( 'success', 'Diagnóstico terminado: el resultado está debajo del estado.' );
				break;

			case 'reinstall_guard':
				$ok = OneBit_WPM_Guard::install();
				self::flash( $ok ? 'success' : 'error', $ok ? 'Guardia de rescate instalada.' : 'No se pudo escribir en wp-content/mu-plugins.' );
				break;
		}

		wp_safe_redirect( self::url() );
		exit;
	}

	private static function button( $do, $label, $extra = array(), $class = 'button', $confirm = '' ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
			<?php wp_nonce_field( self::ACTION ); ?>
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
			<input type="hidden" name="do" value="<?php echo esc_attr( $do ); ?>">
			<?php foreach ( $extra as $name => $value ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>">
			<?php endforeach; ?>
			<button type="submit" class="<?php echo esc_attr( $class ); ?>"<?php echo $confirm ? ' onclick="return confirm(' . esc_attr( wp_json_encode( $confirm ) ) . ')"' : ''; ?>><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}

	private static function status_row( $label, $ok, $detail ) {
		printf(
			'<tr><th scope="row">%s</th><td><span class="dashicons %s" style="color:%s"></span> %s</td></tr>',
			esc_html( $label ),
			$ok ? 'dashicons-yes-alt' : 'dashicons-warning',
			$ok ? '#00a32a' : '#d63638',
			wp_kses( $detail, array( 'code' => array(), 'a' => array( 'href' => array() ), 'strong' => array() ) )
		);
	}

	/**
	 * Motivo corto para la fila de estado, sin leer archivos.
	 */
	private static function app_password_reason() {
		$d = OneBit_WPM_Diagnostics::application_passwords();

		if ( ! $d['supported'] ) {
			return 'WordPress no detecta que la conexión sea HTTPS (común detrás de un CDN o proxy). Usá Diagnosticar para ver los detalles.';
		}
		if ( $d['callbacks'] ) {
			$first = $d['callbacks'][0];
			return sprintf( 'las desactiva un filtro: %s, %s. Usá Diagnosticar para ubicarlo.', $first['callback'], $first['where'] );
		}

		return 'algo las desactiva para este usuario. Usá Diagnosticar para buscarlo.';
	}

	private static function render_diagnosis() {
		$scan = get_transient( 'onebit_wpm_diagnosis_' . get_current_user_id() );
		if ( ! $scan || wp_is_application_passwords_available() ) {
			return;
		}

		$d    = OneBit_WPM_Diagnostics::application_passwords();
		$list = function ( $items ) {
			return '<ul style="list-style:disc;margin-left:20px">' . implode( '', array_map( function ( $i ) {
				return '<li>' . $i . '</li>';
			}, $items ) ) . '</ul>';
		};
		?>
		<div class="card" style="max-width:none;margin:12px 0 20px">
			<h2 style="margin-top:0">Por qué no hay contraseñas de aplicación</h2>

			<h3>1. HTTPS</h3>
			<?php if ( $d['supported'] ) : ?>
				<p><span class="dashicons dashicons-yes-alt" style="color:#00a32a"></span> WordPress detecta la conexión como segura: no es este el problema.</p>
			<?php else : ?>
				<p><span class="dashicons dashicons-warning" style="color:#d63638"></span> <strong>WordPress no detecta HTTPS</strong> (<code>is_ssl()</code> es falso). Por eso oculta las contraseñas de aplicación, aunque el navegador muestre el candado.</p>
				<p>Lo que ve el servidor: <code><?php echo esc_html( wp_json_encode( $d['https_hints'] ) ); ?></code></p>
				<p>Suele pasar cuando un CDN o proxy recibe el HTTPS y le pasa el pedido al servidor por HTTP. La solución es agregar en <code>wp-config.php</code>, antes de <code>/* That's all, stop editing! */</code>, desde el administrador de archivos del hosting:</p>
				<pre style="background:#f6f7f7;padding:10px;overflow:auto">if ( isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) &amp;&amp; 'https' === $_SERVER['HTTP_X_FORWARDED_PROTO'] ) {
	$_SERVER['HTTPS'] = 'on';
}</pre>
			<?php endif; ?>

			<h3>2. Filtros activos que las desactivan</h3>
			<?php if ( ! $d['callbacks'] ) : ?>
				<p>Ninguno enganchado en este momento.</p>
			<?php else : ?>
				<?php
				echo $list( array_map( function ( $c ) { // phpcs:ignore WordPress.Security.EscapeOutput
					return sprintf( '<code>%s</code> → <strong>%s</strong> <span style="color:#646970">(prioridad %s%s)</span>',
						esc_html( $c['callback'] ), esc_html( $c['where'] ), esc_html( $c['priority'] ), $c['file'] ? ', ' . esc_html( $c['file'] ) : '' );
				}, $d['callbacks'] ) );
				?>
			<?php endif; ?>

			<h3>3. Código que las menciona</h3>
			<p style="color:#646970">Se revisaron <?php echo esc_html( $scan['files'] ); ?> archivos PHP en <?php echo esc_html( $scan['seconds'] ); ?> s<?php echo $scan['partial'] ? ' (búsqueda cortada por tiempo: puede faltar algo)' : ''; ?>.</p>
			<?php if ( ! $scan['matches'] ) : ?>
				<p>No apareció en plugins, temas ni mu-plugins.</p>
			<?php else : ?>
				<?php
				echo $list( array_map( function ( $m ) { // phpcs:ignore WordPress.Security.EscapeOutput
					return sprintf( '<strong>%s</strong> — %s:%d<br><code>%s</code>', esc_html( $m['where'] ), esc_html( $m['file'] ), (int) $m['line'], esc_html( $m['code'] ) );
				}, $scan['matches'] ) );
				?>
			<?php endif; ?>

			<h3>4. Snippets y ajustes guardados en la base</h3>
			<?php $db = array_merge( $scan['snippets'], $scan['settings'] ); ?>
			<?php if ( ! $db ) : ?>
				<p>Nada en Code Snippets, WPCode ni en los ajustes de Wordfence.</p>
			<?php else : ?>
				<?php echo $list( array_map( 'esc_html', $db ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function render() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			return;
		}

		$flash = get_transient( 'onebit_wpm_flash_' . get_current_user_id() );
		delete_transient( 'onebit_wpm_flash_' . get_current_user_id() );

		$env      = OneBit_WPM_Updater::environment();
		$loopback = get_option( self::LOOPBACK_OPTION );
		$user     = wp_get_current_user();
		$host     = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$env_name = strtoupper( trim( preg_replace( '/[^A-Za-z0-9]+/', '_', $host ), '_' ) );

		$snippet = array(
			'name'         => sanitize_title( $host ),
			'url'          => home_url(),
			'user'         => $user->user_login,
			'app_password' => 'env:' . $env_name . '_APP_PW',
			'token'        => 'env:' . $env_name . '_TOKEN',
			'health_paths' => array( '/' ),
			'hold'         => array(),
		);
		?>
		<div class="wrap">
			<h1>1Bit WP Maintenance</h1>

			<?php if ( $flash && 'token' === $flash['type'] ) : ?>
				<div class="notice notice-warning">
					<p><strong>Token nuevo.</strong> Copialo ahora: no se vuelve a mostrar. El token anterior dejó de funcionar.</p>
					<p><input type="text" readonly class="large-text code" value="<?php echo esc_attr( $flash['message'] ); ?>" onclick="this.select()"></p>
					<p>En tu <code>secrets.json</code>: <code><?php echo esc_html( $env_name ); ?>_TOKEN</code></p>
				</div>
			<?php elseif ( $flash ) : ?>
				<div class="notice notice-<?php echo 'success' === $flash['type'] ? 'success' : 'error'; ?> is-dismissible"><p><?php echo esc_html( $flash['message'] ); ?></p></div>
			<?php endif; ?>

			<h2>Estado</h2>
			<table class="form-table" role="presentation"><tbody>
				<?php
				self::status_row(
					'Token',
					OneBit_WPM_Token::is_configured(),
					OneBit_WPM_Token::is_configured() ? 'Configurado.' : 'Sin configurar: el orquestador no puede conectarse. Generalo en <strong>Conexión</strong>.'
				);
				self::status_row(
					'Contraseñas de aplicación',
					wp_is_application_passwords_available(),
					wp_is_application_passwords_available()
						? sprintf( 'Disponibles. <a href="%s">Crear una para wpmaint</a>.', esc_url( admin_url( 'profile.php#application-passwords-section' ) ) )
						: 'No disponibles: ' . esc_html( self::app_password_reason() )
				);
				self::status_row(
					'Guardia de rescate',
					$env['guard_installed'],
					$env['guard_installed'] ? 'Instalada en <code>mu-plugins</code>.' : 'No instalada: si una actualización tira un error fatal, el rollback remoto puede no responder.'
				);
				self::status_row(
					'Escritura en disco',
					$env['filesystem_ok'] && $env['file_mods_allowed'],
					! $env['file_mods_allowed']
						? '<code>DISALLOW_FILE_MODS</code> está activo: no se puede actualizar.'
						: ( $env['filesystem_ok'] ? 'Directa.' : sprintf( 'Método <code>%s</code>: WordPress pediría credenciales FTP y el update fallaría.', esc_html( $env['filesystem_method'] ) ) )
				);
				self::status_row( 'Compresión de backups', true, esc_html( $env['archiver'] ) );
				self::status_row(
					'Snapshots de base',
					$env['db_snapshots'],
					$env['db_snapshots']
						? sprintf( 'Disponibles. Base de %s, cifrado AES-256-GCM.', esc_html( size_format( $env['db_bytes'] ) ) )
						: 'No disponibles: ' . esc_html( $env['db_snapshots_reason'] ) . '.'
				);
				self::status_row(
					'Loopback',
					$loopback && $loopback['result']['ok'],
					$loopback
						? sprintf(
							'%s (probado %s). %s',
							$loopback['result']['ok'] ? 'Funciona' : 'Falló: ' . esc_html( $loopback['result']['summary'] ),
							esc_html( human_time_diff( $loopback['time'] ) . ' atrás' ),
							$loopback['result']['ok'] ? '' : 'Sin loopback solo queda la verificación externa del orquestador.'
						)
						: 'Sin probar.'
				);
				self::status_row( 'Versiones', true, sprintf( 'WordPress %s · PHP %s · plugin %s', esc_html( $env['wp_version'] ), esc_html( $env['php_version'] ), esc_html( $env['plugin_version'] ) ) );
				?>
			</tbody></table>
			<p>
				<?php self::button( 'loopback', 'Probar loopback' ); ?>
				<?php if ( ! $env['guard_installed'] ) : ?>
					<?php self::button( 'reinstall_guard', 'Reinstalar guardia' ); ?>
				<?php endif; ?>
				<?php if ( ! wp_is_application_passwords_available() ) : ?>
					<?php self::button( 'diagnose_app_passwords', 'Diagnosticar contraseñas de aplicación', array(), 'button button-primary' ); ?>
				<?php endif; ?>
			</p>
			<?php self::render_diagnosis(); ?>

			<h2>Conexión</h2>
			<ol>
				<li><a href="<?php echo esc_url( admin_url( 'profile.php#application-passwords-section' ) ); ?>">Creá una contraseña de aplicación</a> llamada <code>wpmaint</code> y guardala como <code><?php echo esc_html( $env_name ); ?>_APP_PW</code>.</li>
				<li>Generá el token y guardalo como <code><?php echo esc_html( $env_name ); ?>_TOKEN</code>.
					<?php self::button( 'generate_token', OneBit_WPM_Token::is_configured() ? 'Regenerar token' : 'Generar token', array(), 'button button-primary', OneBit_WPM_Token::is_configured() ? 'El token actual dejará de funcionar y los snapshots de base existentes ya no se podrán restaurar. ¿Continuar?' : '' ); ?>
				</li>
				<li>Agregá este bloque a <code>sites.json</code>:</li>
			</ol>
			<textarea readonly class="large-text code" rows="11" onclick="this.select()"><?php echo esc_textarea( wp_json_encode( $snippet, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></textarea>

			<h2>Backups</h2>
			<?php $backups = OneBit_WPM_Backups::all(); ?>
			<?php if ( ! $backups ) : ?>
				<p>Todavía no hay backups.</p>
			<?php else : ?>
				<table class="widefat striped">
					<thead><tr><th>Fecha</th><th>Tipo</th><th>Item</th><th>Versión respaldada</th><th>Tamaño</th><th></th></tr></thead>
					<tbody>
					<?php foreach ( $backups as $backup ) : ?>
						<tr>
							<td><?php echo esc_html( wp_date( 'Y-m-d H:i', $backup['created'] ) ); ?></td>
							<td><?php echo 'plugin' === $backup['type'] ? 'Plugin' : 'Tema'; ?></td>
							<td><code><?php echo esc_html( $backup['item'] ); ?></code></td>
							<td><?php echo esc_html( $backup['version_before'] ); ?><?php echo ! empty( $backup['restored_at'] ) ? ' <em>(restaurado)</em>' : ''; ?></td>
							<td><?php echo esc_html( size_format( $backup['size'] ) ); ?></td>
							<td style="text-align:right">
								<?php self::button( 'restore', 'Restaurar', array( 'backup_id' => $backup['backup_id'] ), 'button', sprintf( '¿Restaurar %s a la versión %s?', $backup['item'], $backup['version_before'] ) ); ?>
								<?php self::button( 'delete', 'Borrar', array( 'backup_id' => $backup['backup_id'] ), 'button-link button-link-delete', '¿Borrar este backup?' ); ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:1em">
				<?php wp_nonce_field( self::ACTION ); ?>
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
				<input type="hidden" name="do" value="settings">
				<label>Conservar backups durante
					<input type="number" name="retention_days" min="1" max="365" class="small-text" value="<?php echo esc_attr( OneBit_WPM_Plugin::retention_days() ); ?>"> días
				</label>
				<button type="submit" class="button">Guardar</button>
			</form>

			<h2>Snapshots de base de datos</h2>
			<p>
				Se toman segundos antes de cada actualización, cifrados con el token del orquestador, que no se guarda en este servidor.
				Se borran solos al vencer. Restaurar se hace desde el orquestador
				(<code>python wpmaint.py db-restore</code>): pisa la base entera y pierde todo lo que entró después del snapshot.
			</p>
			<?php $snapshots = OneBit_WPM_Db_Snapshots::all(); ?>
			<?php if ( ! $snapshots ) : ?>
				<p>No hay snapshots guardados.</p>
			<?php else : ?>
				<table class="widefat striped">
					<thead><tr><th>Tomado</th><th>Motivo</th><th>Estado</th><th>Tamaño</th><th>Vence</th><th></th></tr></thead>
					<tbody>
					<?php foreach ( $snapshots as $snapshot ) : ?>
						<tr>
							<td><?php echo esc_html( wp_date( 'Y-m-d H:i', $snapshot['created'] ) ); ?><br><code><?php echo esc_html( $snapshot['snapshot_id'] ); ?></code></td>
							<td><?php echo esc_html( $snapshot['label'] ); ?></td>
							<td>
								<?php
								$labels = array( 'complete' => 'Completo', 'in_progress' => 'En curso', 'failed' => 'Falló' );
								echo esc_html( isset( $labels[ $snapshot['status'] ] ) ? $labels[ $snapshot['status'] ] : $snapshot['status'] );
								if ( ! empty( $snapshot['restore'] ) && 'done' === $snapshot['restore']['phase'] ) {
									echo '<br><em>' . esc_html( 'Restaurado ' . wp_date( 'Y-m-d H:i', $snapshot['restore']['finished'] ) ) . '</em>';
								}
								?>
							</td>
							<td><?php echo esc_html( size_format( $snapshot['size'] ) ); ?></td>
							<td><?php echo esc_html( 'en ' . human_time_diff( time(), $snapshot['expires'] ) ); ?></td>
							<td style="text-align:right"><?php self::button( 'db_delete', 'Borrar', array( 'snapshot_id' => $snapshot['snapshot_id'] ), 'button-link button-link-delete', '¿Borrar este snapshot? No se puede deshacer.' ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:1em">
				<?php wp_nonce_field( self::ACTION ); ?>
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
				<input type="hidden" name="do" value="db_settings">
				<label>Borrar snapshots después de
					<input type="number" name="db_retention_hours" min="1" max="<?php echo esc_attr( OneBit_WPM_Db_Snapshots::MAX_RETENTION ); ?>" class="small-text" value="<?php echo esc_attr( OneBit_WPM_Db_Snapshots::retention_hours() ); ?>"> horas
				</label>
				&nbsp;
				<label>y conservar como máximo
					<input type="number" name="db_keep" min="1" max="<?php echo esc_attr( OneBit_WPM_Db_Snapshots::MAX_KEEP ); ?>" class="small-text" value="<?php echo esc_attr( OneBit_WPM_Db_Snapshots::keep() ); ?>">
				</label>
				<button type="submit" class="button">Guardar</button>
			</form>

			<h2>Registro</h2>
			<?php $entries = OneBit_WPM_Log::all( 50 ); ?>
			<?php if ( ! $entries ) : ?>
				<p>Sin eventos.</p>
			<?php else : ?>
				<table class="widefat striped">
					<thead><tr><th style="width:140px">Fecha</th><th style="width:80px">Nivel</th><th>Evento</th></tr></thead>
					<tbody>
					<?php foreach ( $entries as $entry ) : ?>
						<tr>
							<td><?php echo esc_html( wp_date( 'Y-m-d H:i', $entry['time'] ) ); ?></td>
							<td><?php echo esc_html( $entry['level'] ); ?></td>
							<td><?php echo esc_html( $entry['message'] ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}
}
