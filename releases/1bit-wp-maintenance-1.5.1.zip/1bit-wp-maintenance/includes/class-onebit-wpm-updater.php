<?php
/**
 * Inventario de actualizaciones y ciclo backup -> update -> verificación -> rollback.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Updater {

	const LOCK_OPTION = 'onebit_wpm_lock';
	const LOCK_TTL    = 900;

	public static function load_admin_includes() {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/theme.php';
		require_once ABSPATH . 'wp-admin/includes/update.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	}

	public static function environment() {
		self::load_admin_includes();

		$method = get_filesystem_method( array(), WP_CONTENT_DIR );

		return array(
			'plugin_version'    => ONEBIT_WPM_VERSION,
			'wp_version'        => get_bloginfo( 'version' ),
			'php_version'       => PHP_VERSION,
			'filesystem_method' => $method,
			'filesystem_ok'     => 'direct' === $method,
			'file_mods_allowed' => wp_is_file_mod_allowed( 'onebit_wpm_update' ),
			'archiver'          => class_exists( 'ZipArchive' ) ? 'ZipArchive' : 'PclZip',
			'guard_installed'   => OneBit_WPM_Guard::is_current(),
			'db_snapshots'        => null === OneBit_WPM_Db_Snapshots::unavailable_reason(),
			'db_snapshots_reason' => OneBit_WPM_Db_Snapshots::unavailable_reason(),
			'db_bytes'            => OneBit_WPM_Db_Snapshots::database_bytes(),
			'update_manifest'   => OneBit_WPM_Self_Update::state(),
			'rescue_mode'       => defined( 'ONEBIT_WPM_RESCUE' ),
			'multisite'         => is_multisite(),
		);
	}

	/**
	 * @param bool $refresh Fuerza a consultar las fuentes de actualización en vez de usar la caché de 12 h.
	 */
	public static function pending( $refresh = false ) {
		self::load_admin_includes();

		if ( $refresh ) {
			wp_clean_update_cache();
			delete_site_transient( OneBit_WPM_Self_Update::CACHE );
		}

		wp_update_plugins();
		wp_update_themes();
		wp_version_check();

		$self  = plugin_basename( ONEBIT_WPM_FILE );
		$items = array();

		foreach ( get_plugin_updates() as $file => $data ) {
			$update = $data->update;

			$items[] = array(
				'type'           => 'plugin',
				'item'           => $file,
				'slug'           => '.' === dirname( $file ) ? $file : dirname( $file ),
				'name'           => $data->Name,
				'version'        => $data->Version,
				'new_version'    => isset( $update->new_version ) ? $update->new_version : null,
				'active'         => is_plugin_active( $file ),
				'package'        => ! empty( $update->package ),
				'php_compatible' => is_php_version_compatible( isset( $update->requires_php ) ? $update->requires_php : null ),
				// El propio plugin se actualiza al final: si algo sale mal, lo demás ya quedó hecho.
				'is_self'        => $file === $self,
			);
		}

		foreach ( get_theme_updates() as $stylesheet => $theme ) {
			$update = $theme->update;

			$items[] = array(
				'type'           => 'theme',
				'item'           => $stylesheet,
				'slug'           => $stylesheet,
				'name'           => $theme->get( 'Name' ),
				'version'        => $theme->get( 'Version' ),
				'new_version'    => isset( $update['new_version'] ) ? $update['new_version'] : null,
				'active'         => in_array( $stylesheet, array( get_stylesheet(), get_template() ), true ),
				'package'        => ! empty( $update['package'] ),
				'php_compatible' => is_php_version_compatible( isset( $update['requires_php'] ) ? $update['requires_php'] : null ),
			);
		}

		$core        = get_preferred_from_update_core();
		$core_update = ( $core && isset( $core->response ) && 'upgrade' === $core->response ) ? $core->current : null;

		return array(
			'items'       => $items,
			'core_update' => $core_update,
		);
	}

	/**
	 * Inventario completo con el canal de actualización de cada plugin y tema.
	 *
	 * Sirve para distinguir tres situaciones que se ven parecidas:
	 *   - wordpress.org: se actualiza solo;
	 *   - externo: lo actualiza el fabricante (premium con licencia);
	 *   - ninguno: WordPress no tiene de dónde saber si hay versión nueva. Es el caso de
	 *     los plugins "nulled" o abandonados: quedan viejos y nadie se entera.
	 */
	public static function inventory() {
		self::load_admin_includes();
		wp_update_plugins();
		wp_update_themes();

		$plugins    = get_site_transient( 'update_plugins' );
		$themes     = get_site_transient( 'update_themes' );
		$self       = plugin_basename( ONEBIT_WPM_FILE );
		$items      = array();

		foreach ( get_plugins() as $file => $data ) {
			$entry  = null;
			$update = false;

			if ( isset( $plugins->response[ $file ] ) ) {
				$entry  = (array) $plugins->response[ $file ];
				$update = true;
			} elseif ( isset( $plugins->no_update[ $file ] ) ) {
				$entry = (array) $plugins->no_update[ $file ];
			}

			$items[] = self::inventory_row( 'plugin', $file, $data['Name'], $data['Version'], is_plugin_active( $file ), $entry, $update )
				+ array( 'is_self' => $file === $self );
		}

		foreach ( wp_get_themes() as $stylesheet => $theme ) {
			$entry  = null;
			$update = false;

			if ( isset( $themes->response[ $stylesheet ] ) ) {
				$entry  = (array) $themes->response[ $stylesheet ];
				$update = true;
			} elseif ( isset( $themes->no_update[ $stylesheet ] ) ) {
				$entry = (array) $themes->no_update[ $stylesheet ];
			}

			$active  = in_array( $stylesheet, array( get_stylesheet(), get_template() ), true );
			// Un tema hijo nunca tiene actualizaciones propias: se actualiza el padre.
			$items[] = self::inventory_row( 'theme', $stylesheet, $theme->get( 'Name' ), $theme->get( 'Version' ), $active, $entry, $update )
				+ array( 'parent' => $theme->parent() ? $theme->get_template() : null );
		}

		return array( 'items' => $items );
	}

	private static function inventory_row( $type, $item, $name, $version, $active, $entry, $update ) {
		$package = isset( $entry['package'] ) ? (string) $entry['package'] : '';
		$url     = isset( $entry['url'] ) ? (string) $entry['url'] : '';
		$host    = $package ? (string) wp_parse_url( $package, PHP_URL_HOST ) : '';

		if ( ! $entry ) {
			$channel = 'ninguno';
		} elseif ( false !== strpos( $host, 'wordpress.org' ) || false !== strpos( $url, 'wordpress.org' ) ) {
			$channel = 'wordpress.org';
		} else {
			$channel = 'externo';
		}

		return array(
			'type'            => $type,
			'item'            => $item,
			'name'            => $name,
			'version'         => $version,
			'active'          => (bool) $active,
			'update'          => (bool) $update,
			'new_version'     => isset( $entry['new_version'] ) ? $entry['new_version'] : null,
			'package'         => '' !== $package,
			'channel'         => $channel,
			'source'          => $host ? $host : ( $url ? (string) wp_parse_url( $url, PHP_URL_HOST ) : '' ),
		);
	}

	/**
	 * Actualiza un único item con backup previo y rollback automático.
	 *
	 * @return array|WP_Error Resultado con 'status': updated | failed | rolled_back.
	 */
	public static function update( $type, $item, $paths ) {
		if ( ! in_array( $type, array( 'plugin', 'theme' ), true ) ) {
			return new WP_Error( 'onebit_wpm_bad_type', 'type debe ser plugin o theme.', array( 'status' => 400 ) );
		}

		$env = self::environment();

		if ( ! $env['file_mods_allowed'] ) {
			return new WP_Error( 'onebit_wpm_file_mods', 'Este sitio tiene bloqueada la modificación de archivos (DISALLOW_FILE_MODS).', array( 'status' => 409 ) );
		}

		if ( ! $env['filesystem_ok'] ) {
			return new WP_Error(
				'onebit_wpm_filesystem',
				sprintf( 'WordPress no puede escribir directo en disco (método: %s) y pediría credenciales FTP.', $env['filesystem_method'] ),
				array( 'status' => 409 )
			);
		}

		$lock = self::acquire_lock();
		if ( is_wp_error( $lock ) ) {
			return $lock;
		}

		// Si el orquestador corta la conexión a mitad de camino, el ciclo tiene que
		// terminar igual: un update abandonado a medias es peor que uno lento.
		if ( function_exists( 'ignore_user_abort' ) ) {
			ignore_user_abort( true );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			// phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged
			@set_time_limit( 600 );
		}

		try {
			return self::run_update( $type, $item, $paths );
		} finally {
			self::release_lock();
		}
	}

	private static function run_update( $type, $item, $paths ) {
		$pending = null;
		foreach ( self::pending( false )['items'] as $candidate ) {
			if ( $candidate['type'] === $type && $candidate['item'] === $item ) {
				$pending = $candidate;
				break;
			}
		}

		if ( ! $pending ) {
			return new WP_Error( 'onebit_wpm_no_update', sprintf( 'No hay actualización disponible para %s.', $item ), array( 'status' => 404 ) );
		}
		if ( ! $pending['package'] ) {
			return new WP_Error( 'onebit_wpm_no_package', sprintf( '%s no tiene paquete descargable (¿licencia vencida o sin activar?).', $pending['name'] ), array( 'status' => 409 ) );
		}
		if ( ! $pending['php_compatible'] ) {
			return new WP_Error( 'onebit_wpm_php', sprintf( 'La versión nueva de %s no es compatible con PHP %s.', $pending['name'], PHP_VERSION ), array( 'status' => 409 ) );
		}

		// Si el loopback no funciona ANTES de actualizar (hosts que lo bloquean),
		// no se puede usar para juzgar el resultado: queda solo el chequeo externo.
		$baseline = OneBit_WPM_Health::loopback( $paths );

		$backup = OneBit_WPM_Backups::create( $type, $item );
		if ( is_wp_error( $backup ) ) {
			OneBit_WPM_Log::add( 'error', sprintf( 'Backup fallido de %s: %s', $item, $backup->get_error_message() ) );
			return $backup;
		}

		$result = array(
			'type'              => $type,
			'item'              => $item,
			'name'              => $pending['name'],
			'version_before'    => $pending['version'],
			'version_target'    => $pending['new_version'],
			'backup_id'         => $backup['backup_id'],
			'verified_loopback' => $baseline['ok'],
			'loopback_baseline' => $baseline,
		);

		$upgrade                 = self::run_upgrader( $type, $item );
		$result['version_after'] = OneBit_WPM_Backups::current_version( $type, $item );

		if ( is_wp_error( $upgrade ) ) {
			$result['status'] = 'failed';
			$result['error']  = $upgrade->get_error_message();

			// Si el upgrader dejó el item borrado o a medio instalar, se repone el backup.
			if ( $result['version_after'] !== $pending['version'] ) {
				self::attach_restore( $result, $backup['backup_id'], $type, $item );
			}

			OneBit_WPM_Log::add( 'error', sprintf( 'Falló la actualización de %s: %s', $pending['name'], $result['error'] ), array( 'backup_id' => $backup['backup_id'] ) );
			return $result;
		}

		if ( $baseline['ok'] ) {
			$after                    = OneBit_WPM_Health::loopback( $paths );
			$result['loopback_after'] = $after;

			if ( ! $after['ok'] ) {
				$result['status'] = 'rolled_back';
				$result['reason'] = $after['summary'];

				self::attach_restore( $result, $backup['backup_id'], $type, $item );

				$recheck                    = OneBit_WPM_Health::loopback( $paths );
				$result['recovered']        = $recheck['ok'];
				$result['loopback_recheck'] = $recheck;

				OneBit_WPM_Log::add(
					$recheck['ok'] ? 'warning' : 'error',
					sprintf(
						'%s %s rompió el sitio (%s). Revertido a %s; %s.',
						$pending['name'],
						$pending['new_version'],
						$after['summary'],
						$pending['version'],
						$recheck['ok'] ? 'el sitio se recuperó' : 'EL SITIO SIGUE CON PROBLEMAS: ' . $recheck['summary']
					),
					array( 'backup_id' => $backup['backup_id'] )
				);

				return $result;
			}
		}

		// Si se actualizó a sí mismo, la REST API nueva tiene que responder: sin ella el
		// orquestador y la ruta de rescate pierden el acceso al sitio.
		if ( 'plugin' === $type && plugin_basename( ONEBIT_WPM_FILE ) === $item && $baseline['ok'] && ! OneBit_WPM_Self_Update::rest_alive() ) {
			$result['status'] = 'rolled_back';
			$result['reason'] = 'la versión nueva del plugin de mantenimiento no registra su REST API';
			self::attach_restore( $result, $backup['backup_id'], $type, $item );
			$result['recovered'] = OneBit_WPM_Self_Update::rest_alive();

			OneBit_WPM_Log::add( 'error', sprintf( 'La versión %s del plugin de mantenimiento no registró su REST API: se volvió a %s.', $pending['new_version'], $pending['version'] ) );
			return $result;
		}

		$result['status'] = 'updated';

		if ( 'plugin' === $type ) {
			$result['active_after'] = is_plugin_active( $item );
		}

		OneBit_WPM_Log::add(
			'info',
			sprintf(
				'%s actualizado %s -> %s%s.',
				$pending['name'],
				$pending['version'],
				$result['version_after'],
				$baseline['ok'] ? '' : ' (sin verificación por loopback: el servidor no permite peticiones a sí mismo)'
			),
			array( 'backup_id' => $backup['backup_id'] )
		);

		return $result;
	}

	private static function attach_restore( array &$result, $backup_id, $type, $item ) {
		$restore            = OneBit_WPM_Backups::restore( $backup_id );
		$result['restored'] = ! is_wp_error( $restore );

		if ( is_wp_error( $restore ) ) {
			$result['restore_error'] = $restore->get_error_message();
		}

		$result['version_after'] = OneBit_WPM_Backups::current_version( $type, $item );
	}

	/**
	 * Corre el upgrader del core.
	 *
	 * Se usa bulk_upgrade() y no upgrade(): fuera de WP-Cron, upgrade() desactiva
	 * el plugin antes de instalar y deja la reactivación a cargo de la pantalla
	 * de wp-admin. Por REST no hay pantalla, y el plugin quedaría desactivado.
	 *
	 * @return true|WP_Error
	 */
	private static function run_upgrader( $type, $item ) {
		self::load_admin_includes();

		ob_start();
		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = ( 'plugin' === $type ) ? new Plugin_Upgrader( $skin ) : new Theme_Upgrader( $skin );
		$results  = $upgrader->bulk_upgrade( array( $item ) );
		ob_end_clean();

		// Si algo cortó el proceso, que el sitio no quede en modo mantenimiento.
		global $wp_filesystem;
		if ( $wp_filesystem instanceof WP_Filesystem_Base ) {
			$upgrader->maintenance_mode( false );
		}

		if ( is_wp_error( $skin->result ) ) {
			return $skin->result;
		}
		if ( $skin->get_errors()->has_errors() ) {
			return new WP_Error( 'onebit_wpm_upgrade_failed', $skin->get_error_messages() );
		}
		if ( false === $results ) {
			return new WP_Error( 'onebit_wpm_upgrade_fs', 'El upgrader no pudo acceder al sistema de archivos.' );
		}
		if ( ! is_array( $results ) || empty( $results[ $item ] ) ) {
			return new WP_Error( 'onebit_wpm_upgrade_empty', 'El upgrader no devolvió resultado.' );
		}
		if ( is_wp_error( $results[ $item ] ) ) {
			return $results[ $item ];
		}
		if ( true === $results[ $item ] ) {
			return new WP_Error( 'onebit_wpm_up_to_date', 'WordPress no encontró la actualización al momento de instalar.' );
		}

		return true;
	}

	/**
	 * Restauración manual o de rescate, con el mismo candado que las actualizaciones.
	 *
	 * @param bool $force Ignora un candado tomado (por ejemplo, de un proceso que PHP mató por tiempo).
	 */
	public static function rollback( $backup_id, $force = false ) {
		$lock = self::acquire_lock( $force );
		if ( is_wp_error( $lock ) ) {
			return $lock;
		}

		try {
			self::load_admin_includes();
			$result = OneBit_WPM_Backups::restore( $backup_id );
		} finally {
			self::release_lock();
		}

		if ( is_wp_error( $result ) ) {
			OneBit_WPM_Log::add( 'error', sprintf( 'Falló la restauración del backup %s: %s', $backup_id, $result->get_error_message() ) );
			return $result;
		}

		OneBit_WPM_Log::add(
			'warning',
			sprintf( 'Restaurado %s a %s desde el backup %s%s.', $result['item'], $result['version_restored'], $backup_id, defined( 'ONEBIT_WPM_RESCUE' ) ? ' (modo rescate)' : '' )
		);

		return $result;
	}

	private static function acquire_lock( $force = false ) {
		$now = time();

		if ( add_option( self::LOCK_OPTION, $now, '', 'no' ) ) {
			return true;
		}

		$since = (int) get_option( self::LOCK_OPTION );

		if ( $force || ! $since || ( $now - $since ) > self::LOCK_TTL ) {
			update_option( self::LOCK_OPTION, $now, false );
			return true;
		}

		return new WP_Error( 'onebit_wpm_locked', 'Ya hay una actualización o restauración en curso en este sitio.', array( 'status' => 409 ) );
	}

	private static function release_lock() {
		delete_option( self::LOCK_OPTION );
	}
}
