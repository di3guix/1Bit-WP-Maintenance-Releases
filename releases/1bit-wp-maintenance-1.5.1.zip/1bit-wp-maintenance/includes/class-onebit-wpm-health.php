<?php
/**
 * Verificación de salud por loopback, desde el propio servidor.
 *
 * Usa el mecanismo de "scrape" del core (el mismo que protege al editor de
 * archivos y a las actualizaciones automáticas): la petición lleva una clave
 * y WordPress imprime al final el último error fatal de PHP entre marcadores.
 * Así se detecta el fatal aunque el sitio muestre una página genérica o HTTP 200.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Health {

	const MAX_PATHS = 10;

	/**
	 * Textos de un WordPress roto que igual puede devolver HTTP 200.
	 */
	const SIGNATURES = array(
		'There has been a critical error',
		'Ha habido un error crítico',
		'Ha ocurrido un error crítico',
		'Error establishing a database connection',
		'Error al establecer una conexión con la base de datos',
		'Briefly unavailable for scheduled maintenance',
	);

	public static function sanitize_paths( $paths ) {
		$clean = array();

		foreach ( is_array( $paths ) ? $paths : array() as $path ) {
			$path = '/' . ltrim( trim( (string) $path ), '/' );
			if ( preg_match( '#^/[^\s\\\\]*$#', $path ) && false === strpos( $path, '//' ) ) {
				$clean[] = $path;
			}
		}

		$clean = array_values( array_unique( $clean ) );

		return $clean ? array_slice( $clean, 0, self::MAX_PATHS ) : array( '/' );
	}

	/**
	 * @return array{reachable: bool, ok: bool, summary: string, checks: array}
	 */
	public static function loopback( $paths ) {
		$checks = array();

		foreach ( self::sanitize_paths( $paths ) as $path ) {
			$check    = self::probe( $path );
			$checks[] = $check;

			if ( ! $check['ok'] ) {
				break;
			}
		}

		$failed = null;
		foreach ( $checks as $check ) {
			if ( ! $check['ok'] ) {
				$failed = $check;
				break;
			}
		}

		return array(
			'reachable' => ! $failed || $failed['reachable'],
			'ok'        => ! $failed,
			'summary'   => $failed ? $failed['path'] . ': ' . $failed['detail'] : 'ok',
			'checks'    => $checks,
		);
	}

	private static function probe( $path ) {
		$key   = md5( wp_generate_password( 32, false, false ) );
		$nonce = wp_generate_password( 20, false, false );

		set_transient( 'scrape_key_' . $key, $nonce, 120 );

		$url = add_query_arg(
			array(
				'wp_scrape_key'    => $key,
				'wp_scrape_nonce'  => $nonce,
				'onebit_wpm_probe' => time(),
			),
			home_url( $path )
		);

		$started  = microtime( true );
		$response = wp_remote_get(
			$url,
			array(
				'timeout'     => 30,
				'redirection' => 5,
				/** Este filtro es el que usa el core para sus propios loopbacks. */
				'sslverify'   => apply_filters( 'https_local_ssl_verify', false ),
				'headers'     => array(
					'Cache-Control' => 'no-cache',
					'Pragma'        => 'no-cache',
				),
				'user-agent'  => 'OneBit-WPM-Loopback/' . ONEBIT_WPM_VERSION,
			)
		);
		$elapsed = round( microtime( true ) - $started, 2 );

		delete_transient( 'scrape_key_' . $key );

		$base = array(
			'path' => $path,
			'time' => $elapsed,
		);

		if ( is_wp_error( $response ) ) {
			return $base + array(
				'reachable' => false,
				'ok'        => false,
				'status'    => 0,
				'detail'    => 'sin respuesta: ' . $response->get_error_message(),
			);
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = (string) wp_remote_retrieve_body( $response );

		$fatal = self::scrape_error( $body, $key );
		if ( $fatal ) {
			return $base + array(
				'reachable' => true,
				'ok'        => false,
				'status'    => $status,
				'detail'    => 'error fatal de PHP: ' . $fatal,
			);
		}

		if ( $status >= 500 ) {
			return $base + array(
				'reachable' => true,
				'ok'        => false,
				'status'    => $status,
				'detail'    => 'HTTP ' . $status,
			);
		}

		foreach ( self::SIGNATURES as $signature ) {
			if ( false !== stripos( $body, $signature ) ) {
				return $base + array(
					'reachable' => true,
					'ok'        => false,
					'status'    => $status,
					'detail'    => 'la página muestra: ' . $signature,
				);
			}
		}

		return $base + array(
			'reachable' => true,
			'ok'        => true,
			'status'    => $status,
			'detail'    => 'HTTP ' . $status,
		);
	}

	/**
	 * Extrae el error fatal que WordPress imprime entre los marcadores de scrape.
	 *
	 * @return string|null Mensaje del error, o null si no hubo fatal.
	 */
	private static function scrape_error( $body, $key ) {
		$start = "###### wp_scraping_result_start:$key ######";
		$end   = "###### wp_scraping_result_end:$key ######";

		$pos = strpos( $body, $start );
		if ( false === $pos ) {
			return null;
		}

		$chunk = substr( $body, $pos + strlen( $start ) );
		$stop  = strpos( $chunk, $end );
		if ( false !== $stop ) {
			$chunk = substr( $chunk, 0, $stop );
		}

		$result = json_decode( trim( $chunk ), true );

		if ( ! is_array( $result ) ) {
			return null;
		}

		// "success" = sin fatal; "scrape_nonce_failure" es un problema de la sonda, no del sitio.
		if ( isset( $result['code'] ) && in_array( $result['code'], array( 'success', 'scrape_nonce_failure' ), true ) ) {
			return null;
		}

		$message = isset( $result['message'] ) ? (string) $result['message'] : 'error desconocido';

		// El mensaje de una excepción no capturada trae el stack trace entero: para
		// el registro y el reporte alcanza con la primera línea y el archivo.
		$message = strtok( $message, "\n" );
		$message = str_replace( wp_normalize_path( ABSPATH ), '', wp_normalize_path( $message ) );

		if ( isset( $result['file'], $result['line'] ) ) {
			$file     = str_replace( wp_normalize_path( ABSPATH ), '', wp_normalize_path( (string) $result['file'] ) );
			$message .= sprintf( ' (%s:%d)', $file, $result['line'] );
		}

		return substr( $message, 0, 400 );
	}
}
