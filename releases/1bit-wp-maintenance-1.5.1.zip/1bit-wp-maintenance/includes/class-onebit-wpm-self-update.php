<?php
/**
 * Autoactualización del propio plugin desde el repositorio público de releases.
 *
 * El repositorio publica un manifiesto (update.json) con la versión, la URL del zip, su
 * SHA-256 y una firma Ed25519 de esos datos. La clave privada vive solo en la PC de quien
 * publica; acá está la pública. Un manifiesto sin firma válida se ignora, y un zip cuyo hash
 * no coincide con el firmado no se instala: aunque alguien tomara el repositorio, no podría
 * meter código en los sitios.
 *
 * WordPress ve la versión nueva como cualquier actualización pendiente, así que el
 * orquestador la instala con el mismo ciclo de backup, verificación y rollback.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Self_Update {

	const SLUG           = '1bit-wp-maintenance';
	const CACHE          = 'onebit_wpm_self_update_manifest';
	const CACHE_OK       = 6 * HOUR_IN_SECONDS;
	const CACHE_ERROR    = HOUR_IN_SECONDS;
	const DEFAULT_URL    = 'https://raw.githubusercontent.com/di3guix/1Bit-WP-Maintenance-Releases/main/update.json';
	const REPOSITORY_URL = 'https://github.com/di3guix/1Bit-WP-Maintenance-Releases';

	public static function boot() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ) );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'verify_download' ), 10, 4 );
	}

	public static function manifest_url() {
		return (string) apply_filters( 'onebit_wpm_update_manifest_url', self::DEFAULT_URL );
	}

	/**
	 * Clave pública Ed25519 (base64). Solo en entornos locales se puede reemplazar por filtro,
	 * para probar con claves de prueba.
	 */
	private static function public_key() {
		$key = ONEBIT_WPM_UPDATE_PUBKEY;
		if ( 'local' === wp_get_environment_type() ) {
			$key = (string) apply_filters( 'onebit_wpm_update_public_key', $key );
		}
		return $key;
	}

	/**
	 * Mensaje firmado: incluye la URL del paquete para que no se pueda redirigir a otro zip.
	 */
	public static function signed_message( array $manifest ) {
		return implode( "\n", array( self::SLUG, $manifest['version'], $manifest['sha256'], $manifest['package'] ) );
	}

	/**
	 * @return array|WP_Error Manifiesto con firma válida.
	 */
	/**
	 * Qué manifiesto está viendo este sitio: sirve para entender por qué no se ofrece una versión.
	 */
	public static function state() {
		$manifest = self::manifest();

		return array(
			'url'     => self::manifest_url(),
			'version' => is_wp_error( $manifest ) ? null : $manifest['version'],
			'error'   => is_wp_error( $manifest ) ? $manifest->get_error_message() : null,
			'cached'  => is_array( get_site_transient( self::CACHE ) ),
		);
	}

	public static function manifest( $force = false ) {
		$cached = $force ? false : get_site_transient( self::CACHE );
		if ( is_array( $cached ) ) {
			return isset( $cached['error'] ) ? new WP_Error( 'onebit_wpm_manifest', $cached['error'] ) : $cached;
		}

		$response = wp_remote_get(
			add_query_arg( 'nocache', time(), self::manifest_url() ),
			array(
				'timeout'    => 15,
				'user-agent' => 'OneBit-WPM/' . ONEBIT_WPM_VERSION . '; ' . home_url(),
				// Algunos servidores quedaban con un manifiesto viejo: hay cachés en el camino que
				// ignoran el parámetro de la URL, pero sí respetan estas cabeceras.
				'headers'    => array(
					'Cache-Control' => 'no-cache, max-age=0',
					'Pragma'        => 'no-cache',
				),
			)
		);

		$manifest = self::parse( $response );

		if ( is_wp_error( $manifest ) ) {
			set_site_transient( self::CACHE, array( 'error' => $manifest->get_error_message() ), self::CACHE_ERROR );
			return $manifest;
		}

		set_site_transient( self::CACHE, $manifest, self::CACHE_OK );
		return $manifest;
	}

	private static function parse( $response ) {
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'onebit_wpm_manifest', 'No se pudo leer el manifiesto de actualizaciones: ' . $response->get_error_message() );
		}
		if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'onebit_wpm_manifest', 'El manifiesto de actualizaciones respondió HTTP ' . wp_remote_retrieve_response_code( $response ) );
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		foreach ( array( 'version', 'package', 'sha256', 'signature' ) as $field ) {
			if ( empty( $data[ $field ] ) || ! is_string( $data[ $field ] ) ) {
				return new WP_Error( 'onebit_wpm_manifest', "El manifiesto de actualizaciones no tiene '$field'." );
			}
		}
		if ( ! preg_match( '/^\d+\.\d+\.\d+$/', $data['version'] ) || ! preg_match( '/^[a-f0-9]{64}$/', $data['sha256'] )
			|| 0 !== strpos( $data['package'], 'https://' ) && 'local' !== wp_get_environment_type() ) {
			return new WP_Error( 'onebit_wpm_manifest', 'El manifiesto de actualizaciones tiene datos inválidos.' );
		}

		if ( ! self::verify_signature( $data ) ) {
			return new WP_Error( 'onebit_wpm_signature', 'La firma del manifiesto de actualizaciones no es válida: se ignora.' );
		}

		return $data;
	}

	public static function verify_signature( array $manifest ) {
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			// WordPress trae sodium_compat para hosts sin la extensión de PHP.
			require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
		}

		$signature = base64_decode( (string) $manifest['signature'], true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		$key       = base64_decode( self::public_key(), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode

		if ( ! $signature || ! $key || 64 !== strlen( $signature ) || 32 !== strlen( $key ) ) {
			return false;
		}

		try {
			return sodium_crypto_sign_verify_detached( $signature, self::signed_message( $manifest ), $key );
		} catch ( Exception $e ) {
			return false;
		}
	}

	/**
	 * Anuncia la versión nueva en la misma tabla que usa WordPress para todos los plugins.
	 */
	public static function inject( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$manifest = self::manifest();
		if ( is_wp_error( $manifest ) ) {
			return $transient;
		}

		$file  = plugin_basename( ONEBIT_WPM_FILE );
		$entry = (object) array(
			'id'           => self::REPOSITORY_URL,
			'slug'         => self::SLUG,
			'plugin'       => $file,
			'new_version'  => $manifest['version'],
			'url'          => self::REPOSITORY_URL,
			'package'      => $manifest['package'],
			'requires'     => isset( $manifest['requires'] ) ? $manifest['requires'] : '',
			'requires_php' => isset( $manifest['requires_php'] ) ? $manifest['requires_php'] : '',
			'tested'       => isset( $manifest['tested'] ) ? $manifest['tested'] : '',
		);

		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
			$transient->no_update = array();
		}

		if ( version_compare( $manifest['version'], ONEBIT_WPM_VERSION, '>' ) ) {
			$transient->response[ $file ] = $entry;
			unset( $transient->no_update[ $file ] );
		} else {
			$transient->no_update[ $file ] = $entry;
			unset( $transient->response[ $file ] );
		}

		return $transient;
	}

	/**
	 * Antes de instalar el propio plugin: descarga el zip y compara su SHA-256 con el firmado.
	 * Si no coincide, o si no hay un manifiesto válido que lo respalde, no se instala.
	 */
	public static function verify_download( $reply, $package, $upgrader, $hook_extra = array() ) {
		$is_self = isset( $hook_extra['plugin'] ) && plugin_basename( ONEBIT_WPM_FILE ) === $hook_extra['plugin'];

		if ( false !== $reply || ! $is_self ) {
			return $reply;
		}

		$manifest = self::manifest( true );
		if ( is_wp_error( $manifest ) ) {
			return new WP_Error( 'onebit_wpm_unverified', 'No se instala: ' . $manifest->get_error_message() );
		}
		if ( $package !== $manifest['package'] ) {
			return new WP_Error( 'onebit_wpm_unverified', 'No se instala: el paquete no es el publicado y firmado.' );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		$file = download_url( $package, 300 );
		if ( is_wp_error( $file ) ) {
			return $file;
		}

		if ( ! hash_equals( $manifest['sha256'], (string) hash_file( 'sha256', $file ) ) ) {
			@unlink( $file ); // phpcs:ignore
			return new WP_Error( 'onebit_wpm_bad_package', 'No se instala: el zip descargado no coincide con el publicado y firmado.' );
		}

		return $file;
	}

	/**
	 * Después de actualizarse a sí mismo: la REST API del plugin tiene que seguir registrada,
	 * o el orquestador (y la ruta de rescate) perderían el acceso.
	 */
	public static function rest_alive() {
		$response = wp_remote_get(
			add_query_arg( array( 'rest_route' => '/', 'onebit_wpm_probe' => time() ), home_url( '/' ) ),
			array(
				'timeout'   => 30,
				'sslverify' => apply_filters( 'https_local_ssl_verify', false ),
			)
		);

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		$index = json_decode( wp_remote_retrieve_body( $response ), true );

		return isset( $index['namespaces'] ) && in_array( ONEBIT_WPM_REST_NAMESPACE, (array) $index['namespaces'], true );
	}
}
