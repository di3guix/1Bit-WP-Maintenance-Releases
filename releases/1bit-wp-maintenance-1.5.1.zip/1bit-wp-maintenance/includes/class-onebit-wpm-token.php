<?php
/**
 * Token compartido con el orquestador. Solo se guarda su hash.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Token {

	const OPTION = 'onebit_wpm_token_hash';

	/**
	 * Genera un token nuevo, invalida el anterior y devuelve el valor en claro.
	 * Es la única vez que el valor en claro existe del lado de WordPress.
	 */
	public static function generate() {
		$token = wp_generate_password( 48, false, false );
		update_option( self::OPTION, hash( 'sha256', $token ), false );
		return $token;
	}

	public static function is_configured() {
		return (bool) get_option( self::OPTION );
	}

	public static function verify( $token ) {
		$hash = get_option( self::OPTION );

		if ( ! $hash || ! is_string( $token ) || '' === $token ) {
			return false;
		}

		return hash_equals( (string) $hash, hash( 'sha256', $token ) );
	}
}
