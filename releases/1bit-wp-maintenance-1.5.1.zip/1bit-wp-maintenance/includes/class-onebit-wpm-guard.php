<?php
/**
 * Guardia de rescate: un mu-plugin mínimo que el plugin escribe en wp-content/mu-plugins.
 *
 * Por qué existe: si una actualización deja un error fatal, WordPress falla en
 * todas las peticiones, incluida la REST API, y el rollback remoto no podría
 * ejecutarse. Los mu-plugins cargan antes que los plugins normales, así que la
 * guardia puede excluir al resto de los plugins y al tema, pero solo en la ruta
 * de rescate y solo con un token válido.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Guard {

	const FILENAME = '1bit-wp-maintenance-guard.php';

	public static function path() {
		return WPMU_PLUGIN_DIR . '/' . self::FILENAME;
	}

	public static function is_current() {
		$path = self::path();
		return file_exists( $path ) && file_get_contents( $path ) === self::render();
	}

	public static function install() {
		if ( ! is_dir( WPMU_PLUGIN_DIR ) && ! wp_mkdir_p( WPMU_PLUGIN_DIR ) ) {
			OneBit_WPM_Log::add( 'warning', 'No se pudo crear wp-content/mu-plugins: la guardia de rescate no quedó instalada.' );
			return false;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		$written = @file_put_contents( self::path(), self::render(), LOCK_EX );

		if ( false === $written ) {
			OneBit_WPM_Log::add( 'warning', 'No se pudo escribir la guardia de rescate en mu-plugins.' );
			return false;
		}

		return true;
	}

	public static function remove() {
		if ( file_exists( self::path() ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			@unlink( self::path() );
		}
	}

	/**
	 * Reinstala la guardia si falta o quedó desactualizada.
	 */
	public static function ensure() {
		if ( ! self::is_current() ) {
			self::install();
		}
	}

	private static function render() {
		$template = <<<'GUARD'
<?php
/**
 * Plugin Name: 1Bit WP Maintenance - Guardia de rescate
 * Description: Generado por 1bit-wp-maintenance {{VERSION}}. No editar: se regenera solo. Solo actúa en la ruta de rescate con token válido.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

( function () {
	if ( empty( $_SERVER['HTTP_X_1BIT_RESCUE'] ) ) {
		return;
	}

	$route = '';
	if ( isset( $_GET['rest_route'] ) ) {
		$route = (string) $_GET['rest_route'];
	} elseif ( isset( $_SERVER['REQUEST_URI'] ) ) {
		$route = rawurldecode( (string) $_SERVER['REQUEST_URI'] );
	}

	if ( false === strpos( $route, '{{ROUTE}}' ) ) {
		return;
	}

	$hash = get_option( 'onebit_wpm_token_hash' );
	if ( ! $hash || ! hash_equals( (string) $hash, hash( 'sha256', (string) $_SERVER['HTTP_X_1BIT_RESCUE'] ) ) ) {
		return;
	}

	define( 'ONEBIT_WPM_RESCUE', true );

	$self = '{{BASENAME}}';

	// Solo se carga 1bit-wp-maintenance.
	add_filter( 'option_active_plugins', function () use ( $self ) {
		return array( $self );
	}, 1 );

	add_filter( 'site_option_active_sitewide_plugins', function ( $plugins ) use ( $self ) {
		return array_intersect_key( (array) $plugins, array( $self => true ) );
	}, 1 );

	// Un tema inexistente hace que WordPress no incluya ningún functions.php.
	// La REST API no renderiza plantillas, así que no hace falta un tema real.
	$no_theme = function () {
		return 'onebit-wpm-rescue-no-theme';
	};
	add_filter( 'pre_option_template', $no_theme, 1 );
	add_filter( 'pre_option_stylesheet', $no_theme, 1 );

	// Nada de lo filtrado arriba puede terminar guardado en la base.
	foreach ( array( 'active_plugins', 'template', 'stylesheet' ) as $option ) {
		add_filter( 'pre_update_option_' . $option, function ( $value, $old_value ) {
			return $old_value;
		}, 1, 2 );
	}
	add_filter( 'pre_update_site_option_active_sitewide_plugins', function ( $value, $old_value ) {
		return $old_value;
	}, 1, 2 );
} )();

GUARD;

		return strtr(
			$template,
			array(
				'{{BASENAME}}' => plugin_basename( ONEBIT_WPM_FILE ),
				'{{ROUTE}}'    => '/' . ONEBIT_WPM_REST_NAMESPACE . '/rescue/',
				'{{VERSION}}'  => ONEBIT_WPM_VERSION,
			)
		);
	}
}
