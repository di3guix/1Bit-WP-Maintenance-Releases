<?php
/**
 * Señales de licencia de los plugins y temas premium, para distinguir sin preguntar
 * uno con licencia de uno trucho.
 *
 * Tres señales, ninguna definitiva por sí sola:
 *   - licencia guardada: opciones de la base con la clave o el estado de la licencia. Nunca se
 *     devuelve el valor, solo si existe y qué estado dice (válida, vencida…);
 *   - consulta al fabricante: a quién le pregunta cada plugin por actualizaciones y qué responde;
 *   - marcas de pirateo: rastros que dejan los sitios que distribuyen copias truchas.
 *
 * @package 1bit-wp-maintenance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OneBit_WPM_Licenses {

	const SECONDS   = 15;
	const MAX_BYTES = 524288;

	/** Palabras en el nombre de una opción que indican datos de licencia. */
	const OPTION_WORDS = '(licen[cs]e|purchase|activat|regist|serial|product_?key|_token$|[-_]valid$|[-_]code$)';

	/** Opciones con esas palabras que no son licencias: avisos, fechas, integraciones. */
	const OPTION_NOT = '(skip|dismiss|notice|error|time|date|redirect|welcome|popup|recaptcha|mailchimp|drip|activecampaign|getresponse|convertkit|mailerlite|_api_)';

	/**
	 * Rastros de copias piratas: sitios que las distribuyen y firmas típicas. "nulled" solo no
	 * alcanza: aparece en changelogs de librerías serias ("gets nulled when…").
	 */
	const NULLED = '/(\bnulled\s+(by|&|and|team|release)\b|\b(null24|nulljungle|babiato|gpltimes|gplvault|festingervault|wpnull|weadown|codelist\.cc|gplplus|wplocker|themelock|gpldl|pluginsforest|wordpressnull|dlpure|gplkit|freshwp)\b|\bgpl\s(times|vault|club|pal)\b|\bfestinger\svault\b)/i';

	/**
	 * Licencia guardada y marcas de pirateo de un plugin o tema.
	 *
	 * @param string $type 'plugin' o 'theme'.
	 * @param string $item Archivo del plugin (carpeta/archivo.php) o carpeta del tema.
	 * @return array|WP_Error
	 */
	public static function inspect( $type, $item ) {
		OneBit_WPM_Updater::load_admin_includes();

		if ( 'plugin' === $type ) {
			$plugins = get_plugins();
			if ( ! isset( $plugins[ $item ] ) ) {
				return new WP_Error( 'onebit_wpm_not_found', 'No existe ese plugin.', array( 'status' => 404 ) );
			}
			$name = $plugins[ $item ]['Name'];
			$dir  = WP_PLUGIN_DIR . '/' . dirname( $item );
			$slug = dirname( $item );
		} else {
			$theme = wp_get_theme( $item );
			if ( ! $theme->exists() ) {
				return new WP_Error( 'onebit_wpm_not_found', 'No existe ese tema.', array( 'status' => 404 ) );
			}
			$name = $theme->get( 'Name' );
			$dir  = $theme->get_stylesheet_directory();
			$slug = $item;
		}

		return array(
			'type'    => $type,
			'item'    => $item,
			'options' => self::license_options( $slug, $name ),
			'markers' => self::markers( $dir ),
		);
	}

	/**
	 * Busca opciones de licencia por el nombre del plugin: "revslider-valid",
	 * "elementor_pro_license_key", "woodmart_token"…
	 */
	private static function license_options( $slug, $name ) {
		global $wpdb;

		$tokens = array();
		foreach ( array( $slug, sanitize_title( $name ) ) as $source ) {
			$source = strtolower( $source );
			$tokens[] = $source;
			$tokens[] = str_replace( '-', '_', $source );
			// "porto-functionality" -> "porto", "bridge-core" -> "bridge".
			$first = strtok( $source, '-_' );
			if ( $first && strlen( $first ) >= 4 && ! in_array( $first, array( 'woocommerce', 'wordpress', 'elementor', 'advanced', 'ultimate', 'custom', 'theme' ), true ) ) {
				$tokens[] = $first;
			}
		}
		$tokens = array_unique( array_filter( $tokens ) );

		$found = array();
		foreach ( $tokens as $token ) {
			$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
				$wpdb->prepare(
					"SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name NOT LIKE %s AND option_name NOT LIKE %s LIMIT 40",
					'%' . $wpdb->esc_like( $token ) . '%',
					$wpdb->esc_like( '_transient' ) . '%',
					$wpdb->esc_like( '_site_transient' ) . '%'
				),
				ARRAY_A
			);

			foreach ( (array) $rows as $row ) {
				if ( isset( $found[ $row['option_name'] ] ) || ! preg_match( '/' . self::OPTION_WORDS . '/i', $row['option_name'] )
					|| preg_match( '/' . self::OPTION_NOT . '/i', $row['option_name'] ) ) {
					continue;
				}
				$found[ $row['option_name'] ] = array(
					'name'   => $row['option_name'],
					'status' => self::status_of( $row['option_value'] ),
				);
			}
		}

		return array_values( $found );
	}

	/**
	 * Qué dice un valor de licencia, sin devolverlo: una clave es un secreto.
	 */
	private static function status_of( $raw ) {
		$value = maybe_unserialize( $raw );
		$text  = strtolower( is_scalar( $value ) ? (string) $value : (string) wp_json_encode( $value ) );

		if ( '' === trim( $text ) || in_array( trim( $text ), array( 'false', '0', 'null', '[]', '{}', 'no', '""' ), true ) ) {
			return 'vacía';
		}
		if ( preg_match( '/\b(expired|vencid)/', $text ) ) {
			return 'vencida';
		}
		if ( preg_match( '/\b(invalid|inactive|deactivated|disabled|revoked|site_inactive|not_activated)\b/', $text ) ) {
			return 'inválida o inactiva';
		}
		if ( preg_match( '/\b(valid|active|activated|registered|verified)\b/', $text ) || in_array( trim( $text ), array( 'true', '1', 'yes' ), true ) ) {
			return 'válida';
		}

		return strlen( $text ) >= 8 ? 'guardada' : 'vacía';
	}

	/** Rastros de copias piratas en el código. */
	private static function markers( $dir ) {
		$found    = array();
		$deadline = microtime( true ) + self::SECONDS;
		$root     = wp_normalize_path( untrailingslashit( $dir ) );

		if ( ! is_dir( $root ) ) {
			return array();
		}

		$iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, RecursiveDirectoryIterator::SKIP_DOTS ) );
		foreach ( $iterator as $file ) {
			if ( microtime( true ) > $deadline || count( $found ) >= 10 ) {
				break;
			}
			// Solo código: los changelogs y readmes de librerías daban falsos positivos.
			if ( 'php' !== strtolower( $file->getExtension() ) || $file->getSize() > self::MAX_BYTES ) {
				continue;
			}

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$content = (string) @file_get_contents( $file->getPathname() );
			if ( preg_match( self::NULLED, $content, $match, PREG_OFFSET_CAPTURE ) ) {
				$offset  = $match[0][1];
				$found[] = array(
					'file' => ltrim( str_replace( $root, '', wp_normalize_path( $file->getPathname() ) ), '/' ),
					'text' => trim( mb_substr( preg_replace( '/\s+/', ' ', substr( $content, max( 0, $offset - 60 ), 160 ) ), 0, 160 ) ),
				);
			}
		}

		return $found;
	}

	/**
	 * Fuerza la búsqueda de actualizaciones y anota a quién le pregunta cada plugin y qué responde.
	 */
	public static function update_requests() {
		OneBit_WPM_Updater::load_admin_includes();

		$log = array();
		$hook = function ( $response, $context, $class, $args, $url ) use ( &$log ) {
			$host = (string) wp_parse_url( $url, PHP_URL_HOST );
			if ( '' === $host || false !== strpos( $host, 'wordpress.org' ) || false !== strpos( $host, 'raw.githubusercontent.com' ) ) {
				return;
			}

			$component = self::caller();
			$code      = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
			$body      = is_wp_error( $response ) ? $response->get_error_message() : strtolower( substr( (string) wp_remote_retrieve_body( $response ), 0, 4000 ) );

			$log[] = array(
				'component' => $component,
				'host'      => $host,
				'status'    => $code,
				'says'      => self::status_of( $body ),
			);
		};

		add_action( 'http_api_debug', $hook, 10, 5 );
		wp_clean_update_cache();
		wp_update_plugins();
		wp_update_themes();
		remove_action( 'http_api_debug', $hook, 10 );

		return array( 'requests' => $log );
	}

	/** Qué plugin o tema hizo el pedido HTTP, por la pila de llamadas. */
	private static function caller() {
		$plugins = trailingslashit( wp_normalize_path( WP_PLUGIN_DIR ) );
		$themes  = trailingslashit( wp_normalize_path( get_theme_root() ) );
		$self    = wp_normalize_path( ONEBIT_WPM_DIR );

		foreach ( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS ) as $frame ) { // phpcs:ignore WordPress.PHP.DevelopmentFunctions
			if ( empty( $frame['file'] ) ) {
				continue;
			}
			$file = wp_normalize_path( $frame['file'] );
			if ( 0 === strpos( $file, $self ) ) {
				continue;
			}
			if ( 0 === strpos( $file, $plugins ) ) {
				return 'plugin:' . strtok( substr( $file, strlen( $plugins ) ), '/' );
			}
			if ( 0 === strpos( $file, $themes ) ) {
				return 'theme:' . strtok( substr( $file, strlen( $themes ) ), '/' );
			}
		}

		return 'core';
	}
}
